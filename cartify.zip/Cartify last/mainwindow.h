
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "product.h"
#include <QListWidget>
#include <QPushButton>
#include <QMap>
#include "NotificationSystem.h"
#include <QGraphicsScene>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

/**
 * @brief Main application window for Cartify.
 * 
 * The MainWindow class provides the primary GUI for the Cartify system,
 * handling user interaction, product management, shopping cart, and
 * discount functionality. It also manages user authentication and
 * facilitates the purchase process.
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    /**
     * @brief Constructs the MainWindow object and initializes the GUI.
     * 
     * @param parent The parent widget. Defaults to nullptr.
     */
    MainWindow(QWidget *parent = nullptr);

    /**
     * @brief Destroys the MainWindow object and performs cleanup.
     */
    ~MainWindow();

protected:
    /**
     * @brief Handles the close event to perform necessary cleanup.
     * 
     * This function logs out the user and ensures proper cleanup of resources
     * when the application window is closed.
     * 
     * @param event The QCloseEvent triggered when the window is closed.
     */
    void closeEvent(QCloseEvent *event) override;

private slots:
    /**
     * @brief Spins the discount wheel.
     */
    void spinWheel();

    /**
     * @brief Applies a discount to the current purchase.
     * 
     * @param percentage The percentage of the discount to apply.
     */
    void applyDiscount(int percentage);

    /**
     * @brief Handles the search button click event.
     * 
     * Searches for products based on the user's input and updates the GUI
     * with the results.
     */
    void on_searchButton_clicked();

    /**
     * @brief Handles the apply discount button click event.
     * 
     * Validates and applies a discount based on user input.
     */
    void on_applyDiscountButtonClicked();

    /**
     * @brief Handles product selection when a product button is clicked.
     * 
     * @param product The product associated with the clicked button.
     */
    void on_productButtonClicked(Product& product);

    /**
     * @brief Detects the product button click event and processes it.
     */
    void on_productButton_clicked();

    /**
     * @brief Handles the like button click event for a product.
     * 
     * Likes the currently selected product and updates the GUI.
     */
    void on_likeButtonClicked();

    /**
     * @brief Submits a comment for the selected product.
     * 
     * Validates and adds the user's comment to the product's comment list.
     */
    void on_submitCommentButtonClicked();

    /**
     * @brief Displays comments for the given product.
     * 
     * Updates the comment list in the GUI to show comments for the selected product.
     * 
     * @param product The product whose comments are displayed.
     */
    void displayCommentsForProduct(const Product &product);

    /**
     * @brief Navigates to the sign-up page.
     */
    void on_gotoSignUp_clicked();

    /**
     * @brief Handles user sign-up.
     * 
     * Validates user input and registers a new user if valid.
     */
    void on_signUpButton_clicked();

    /**
     * @brief Handles user login.
     * 
     * Validates credentials and logs the user in if valid.
     */
    void on_loginButton_clicked();

    /**
     * @brief Displays the electronics product page.
     */
    void on_electronicsButton_clicked();

    /**
     * @brief Displays the clothes product page.
     */
    void on_clothesButton_clicked();

    /**
     * @brief Navigates back to the main screen.
     */
    void on_mainScreenButton_clicked();

    /**
     * @brief Logs out the current user.
     * 
     * Clears user data and navigates to the login page.
     */
    void on_logoutButton_clicked();

    /**
     * @brief Adds the selected product to the user's favorites.
     */
    void on_product_favoriteButton_clicked();

    /**
     * @brief Sends the selected product to the user's shopping cart.
     */
    void on_product_sendToCart_clicked();

    /**
     * @brief Displays the user's profile page.
     * 
     * Updates the profile page with the user's information.
     */
    void on_profileButton_clicked();

    /**
     * @brief Removes a product from the user's favorites.
     */
    void on_discardButton_clicked();

    /**
     * @brief Sends a favorite product to the shopping cart.
     */
    void on_sendFavoriteToCartButton_clicked();

    /**
     * @brief Displays the cart page.
     */
    void on_cartButton_clicked();

    /**
     * @brief Processes the purchase of items in the cart.
     * 
     * Validates payment and completes the purchase process.
     */
    void on_buyButton_clicked();

    /**
     * @brief Removes an item from the cart.
     */
    void on_removeButton_clicked();

    /**
     * @brief Updates the selected size of a product.
     * 
     * @param arg1 The selected size as a QString.
     */
    void on_sizeComboBox_currentTextChanged(const QString &arg1);

    /**
     * @brief Navigates to the login page.
     */
    void on_pass_to_loginPage_clicked();

    /**
     * @brief Sets the product button with the given picture.
     * 
     * Configures the button's icon and style.
     * 
     * @param button The QPushButton to configure.
     * @param picturePath The path to the product's picture.
     */
    void setProductButton(QPushButton *button, const QString &picturePath);

    /**
     * @brief Initializes product buttons.
     */
    void setupProductButtons();

    /**
     * @brief Displays discount color codes on the GUI.
     */
    void showDiscountColors();

    /**
     * @brief Handles the toggling of the gift wrap checkbox.
     * 
     * Ensures that the checkbox state is valid and updates the GUI accordingly.
     * 
     * @param checked The state of the checkbox (true if checked).
     */
    void on_giftWrapCheckBox_toggled(bool checked);

private:
    Ui::MainWindow *ui; ///< The UI object for the MainWindow.
    QListWidget *commentListWidget; ///< Widget for displaying comments.
    NotificationSystem *notificationSystem; ///< Handles user notifications.
    QVector<Product> products; ///< List of products displayed in the application.
    QVector<QPushButton *> productButtons; ///< Buttons for product selection.
    QMap<QPushButton *, Product *> buttonProductMap; ///< Maps buttons to corresponding products.
    Product* currentProduct; ///< The currently selected product.

    /// Graphics and discount wheel elements
    QGraphicsScene *scene;
    QGraphicsEllipseItem *wheel;
    QTimer *timer;
    int currentAngle;
    int targetAngle;
    QStringList wheelRewards;
    double currentSpeed;
    double minSpeed;
    double deceleration;
    QList<QGraphicsPathItem*> slices;
    QMap<int, QString> colorMap;
    QMap<QString, int> discountMap;
    QTimer *blinkTimer;
    int blinkCount;
    bool blinkState;
    int chosenSliceIndex;
    int currentDiscount;
    bool discountApplied;

    /// Constants
    const double giftWrapFee = 10.0; ///< Fee for gift wrapping.
    
    /// Private helper functions
    void connectProductButtons();
};

#endif // MAINWINDOW_H
