#ifndef USERMANAGER_H
#define USERMANAGER_H

#include "customer.h"
#include "product.h"
#include <QString>
#include <QVector>

/**
 * @brief Manages user accounts and authentication in the Cartify system.
 * 
 * The UserManager class handles user login, registration, and retrieval
 * of the current user's data.
 */
class UserManager {
private:
    Customer currentUser; ///< The currently logged-in user.

public:
    /**
     * @brief Constructs a UserManager object with a default user.
     */
    UserManager();

    /**
     * @brief Retrieves the current logged-in user.
     * 
     * @return A reference to the Customer object representing the current user.
     */
    Customer& getCurrentUser();

    /**
     * @brief Authenticates a user based on email and password.
     * 
     * Searches the stored user data for a matching email and password combination.
     * If successful, updates the current user and their favorites.
     * 
     * @param email The email address provided for login.
     * @param password The password provided for login.
     * @param products The list of products to initialize user favorites.
     * @return True if authentication is successful, false otherwise.
     */
    bool login(const QString &email, const QString &password, const QVector<Product> &products);

    /**
     * @brief Checks if a user is already registered based on email.
     * 
     * Searches the stored user data for a matching email.
     * 
     * @param email The email address to check.
     * @return True if the email is already registered, false otherwise.
     */
    bool isRegistered(const QString &email);

    /**
     * @brief Registers a new user and stores their data.
     * 
     * Saves the provided user details to the user data storage and updates
     * the current user to the newly registered user.
     * 
     * @param name The first name of the user.
     * @param surname The last name of the user.
     * @param email The email address of the user.
     * @param password The password for the user.
     */
    void signUp(const QString &name, const QString &surname, const QString &email, const QString &password);
};

#endif // USERMANAGER_H
