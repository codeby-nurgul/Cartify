var searchData=
[
  ['giftwrapfee_0',['giftWrapFee',['../class_main_window.html#a7c1bedb9c51507afd9e4ed2aeec3be2f',1,'MainWindow']]]
];
