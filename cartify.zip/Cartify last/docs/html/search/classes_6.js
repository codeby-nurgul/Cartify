var searchData=
[
  ['usermanager_0',['UserManager',['../class_user_manager.html',1,'']]]
];
