var searchData=
[
  ['haslikedproduct_0',['hasLikedProduct',['../class_customer.html#a94ede2b3e36d48d0274962030b3867b4',1,'Customer']]],
  ['haspurchasedproduct_1',['hasPurchasedProduct',['../class_customer.html#ad38ca57a2761890703d58dad66d08734',1,'Customer']]]
];
