var searchData=
[
  ['minspeed_0',['minSpeed',['../class_main_window.html#a4536e9f6928af9b01c9c3600e74626af',1,'MainWindow']]]
];
