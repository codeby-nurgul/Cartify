var searchData=
[
  ['addcart_0',['addCart',['../class_customer.html#a0bcc983a542d1c72a16e5114c062c2d1',1,'Customer']]],
  ['addcomment_1',['addComment',['../class_product.html#ae2ac757f4636f526cb64e9112084a3bc',1,'Product']]],
  ['addfavorite_2',['addFavorite',['../class_customer.html#a6c789c723558bc995d894822e6d5adbe',1,'Customer']]],
  ['addpoint_3',['addPoint',['../class_customer.html#a147d5e7b7cd095a8e227e9e081f529a2',1,'Customer::addPoint()'],['../class_receipt.html#ae6ca2c1eaae3fef2fc64b2b8262bd69a',1,'Receipt::addPoint()']]],
  ['addproduct_4',['addProduct',['../class_cart.html#a5491333fdcb2dc698815a97b3e4ce88c',1,'Cart']]],
  ['addpurchasedproduct_5',['addPurchasedProduct',['../class_customer.html#abb7c39919360a0dd8df7a03b0755d6fd',1,'Customer']]],
  ['applydiscount_6',['applyDiscount',['../class_main_window.html#adadbac3846a64909b1228cfcccfd1a7a',1,'MainWindow::applyDiscount()'],['../class_payment.html#ab498e591df6136b3f58b4cddfefd1486',1,'Payment::applyDiscount() const']]],
  ['applydiscountcode_7',['applyDiscountCode',['../class_payment.html#a28f7ef508194884e12be9b15673da68d',1,'Payment']]]
];
