var searchData=
[
  ['scene_0',['scene',['../class_main_window.html#a51ac2b126495216832501cea3929c6f6',1,'MainWindow']]],
  ['selectedsize_1',['selectedSize',['../class_product.html#a92a34f8f8f4d4d14594149f41a88b126',1,'Product']]],
  ['signupbutton_2',['signupButton',['../class_form_widget.html#add3a6457f70410bf4dc2ae189077471a',1,'FormWidget']]],
  ['slices_3',['slices',['../class_main_window.html#a9d321057d5deacbe0503c8ac539d360f',1,'MainWindow']]],
  ['surname_4',['surname',['../class_customer.html#ae69795230c6f3b24ff9711c844a7df4f',1,'Customer']]]
];
