var searchData=
[
  ['name_0',['name',['../class_customer.html#a0f39144a10d4b9ec5caddd9cbcdd8425',1,'Customer']]],
  ['notificationsystem_1',['notificationSystem',['../class_main_window.html#a6fd6d6eb04e14f6ac0da4f94691e7650',1,'MainWindow']]]
];
