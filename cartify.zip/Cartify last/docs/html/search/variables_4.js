var searchData=
[
  ['favorites_0',['favorites',['../class_customer.html#ac85b2f125ec509fe075081b9b83d8485',1,'Customer']]],
  ['formlayout_1',['formLayout',['../class_form_widget.html#afc91bf66d8d3e6da6b043c3f36268731',1,'FormWidget']]]
];
