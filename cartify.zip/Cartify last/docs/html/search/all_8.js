var searchData=
[
  ['id_0',['id',['../class_product.html#a32e802ac149ad39a7a11acd4e804c407',1,'Product']]],
  ['iscartempty_1',['isCartEmpty',['../class_customer.html#ac37ec41ef68631b883e2ff726dff6014',1,'Customer']]],
  ['isregistered_2',['isRegistered',['../class_user_manager.html#a2be0604dd5b436538abf0753b1fb5c60',1,'UserManager']]]
];
