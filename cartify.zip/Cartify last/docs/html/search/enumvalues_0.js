var searchData=
[
  ['clothes_0',['Clothes',['../customer_8h.html#a5d28b0e89cb1a22ecd9963d88181c084aaa311eccee45c457c74cd2680db3b48e',1,'customer.h']]]
];
