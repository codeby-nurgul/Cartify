var searchData=
[
  ['xlarge_0',['XLARGE',['../class_product.html#ab05a4f33be86b263c00d2e4c1b57a5d4ad9e31a9937ae0b6563e00146bab25e01',1,'Product']]],
  ['xsmall_1',['XSMALL',['../class_product.html#ab05a4f33be86b263c00d2e4c1b57a5d4af1e02112dd195586209d082926514c50',1,'Product']]]
];
