var searchData=
[
  ['cart_0',['cart',['../class_customer.html#ae86fc9797406f36fb7d031e0f9662b0e',1,'Customer::cart'],['../class_payment.html#a625ec5c750e12ffc1f76c66712f24602',1,'Payment::cart']]],
  ['chosensliceindex_1',['chosenSliceIndex',['../class_main_window.html#a9c12ad7d256278acb472d1f23b8f2a54',1,'MainWindow']]],
  ['colormap_2',['colorMap',['../class_main_window.html#a9ca7835fef00a616d21bf0007ebc4f59',1,'MainWindow']]],
  ['commentlistwidget_3',['commentListWidget',['../class_main_window.html#a8b740ce21ae0d2718e82950e8c3e0696',1,'MainWindow']]],
  ['comments_4',['comments',['../class_product.html#aa27952646941ce86c169d08d74817627',1,'Product']]],
  ['cost_5',['cost',['../class_product.html#a398f39573e00166f6eda7ff580a86035',1,'Product']]],
  ['currentangle_6',['currentAngle',['../class_main_window.html#aa2364480f21a24d31e435b014025052e',1,'MainWindow']]],
  ['currentdiscount_7',['currentDiscount',['../class_main_window.html#a4a57d827ccdb218c20d609c867e7bfd1',1,'MainWindow']]],
  ['currentproduct_8',['currentProduct',['../class_main_window.html#aea83ea70ca5640ed9d18482138546442',1,'MainWindow']]],
  ['currentspeed_9',['currentSpeed',['../class_main_window.html#add089168e5deaf6226b8537fd861aff4',1,'MainWindow']]],
  ['currentuser_10',['currentUser',['../class_user_manager.html#a0ac9033d39386f401f95a23143817644',1,'UserManager']]],
  ['customer_11',['customer',['../class_payment.html#a4ab236d33f7ac4f51ae1032f95f7bd1a',1,'Payment']]]
];
