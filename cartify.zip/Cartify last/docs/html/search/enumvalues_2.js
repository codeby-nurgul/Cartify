var searchData=
[
  ['electronics_0',['Electronics',['../customer_8h.html#a5d28b0e89cb1a22ecd9963d88181c084aee3c6e8ed9c27c45f161ea416c997df8',1,'customer.h']]]
];
