var searchData=
[
  ['medium_0',['MEDIUM',['../class_product.html#ab05a4f33be86b263c00d2e4c1b57a5d4ac87f3be66ffc3c0d4249f1c2cc5f3cce',1,'Product']]]
];
