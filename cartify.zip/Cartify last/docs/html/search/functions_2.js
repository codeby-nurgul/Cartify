var searchData=
[
  ['discountpercentage_0',['discountPercentage',['../class_payment.html#a05c746e8a19b255dd4b35593fdb41b73',1,'Payment']]],
  ['displaycommentsforproduct_1',['displayCommentsForProduct',['../class_main_window.html#a33defa59252584b88de9d65c823a929e',1,'MainWindow']]]
];
