var searchData=
[
  ['wheel_0',['wheel',['../class_main_window.html#ab3ddf2d326c9a8491cb19a0134e78bb1',1,'MainWindow']]],
  ['wheelrewards_1',['wheelRewards',['../class_main_window.html#af18fac66ac84573a3fba80a3d398ac30',1,'MainWindow']]]
];
