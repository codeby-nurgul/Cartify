var searchData=
[
  ['targetangle_0',['targetAngle',['../class_main_window.html#aacecfae0dd48d4c6f65bdaf5e7cf91c0',1,'MainWindow']]],
  ['timer_1',['timer',['../class_main_window.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]],
  ['totalamount_2',['totalAmount',['../class_purchase_record.html#aa761d3047d7a1cee931cfdf30291c879',1,'PurchaseRecord']]]
];
