var searchData=
[
  ['iscartempty_0',['isCartEmpty',['../class_customer.html#ac37ec41ef68631b883e2ff726dff6014',1,'Customer']]],
  ['isregistered_1',['isRegistered',['../class_user_manager.html#a2be0604dd5b436538abf0753b1fb5c60',1,'UserManager']]]
];
