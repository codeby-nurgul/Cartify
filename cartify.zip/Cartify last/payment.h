#ifndef PAYMENT_H
#define PAYMENT_H

#include "purchaserecord.h"
#include "cart.h"
#include "customer.h"

/**
 * @brief Enum representing available discount types.
 */
enum Discount {
    NoDiscount, ///< No discount applied.
    D10,        ///< 10% discount.
    D20,        ///< 20% discount.
    D50         ///< 50% discount.
};

/**
 * @brief Represents a payment process, including discounts and customer information.
 *
 * The Payment class extends the PurchaseRecord class and provides functionality
 * for calculating totals, applying discounts, and retrieving payment details.
 */
class Payment : public PurchaseRecord {
private:
    Customer customer; ///< The customer making the payment.
    Cart cart;         ///< The cart associated with the payment.
    Discount discount; ///< The discount applied to the payment.

public:
    /**
     * @brief Constructs a Payment object.
     *
     * @param customer The customer making the payment.
     * @param cart The shopping cart being purchased.
     * @param discount The discount type applied to the payment.
     */
    Payment(Customer customer, Cart cart, Discount discount);

    /**
     * @brief Sets the discount type.
     *
     * @param discount The discount to apply.
     */
    void setDiscount(Discount discount);

    /**
     * @brief Retrieves the currently applied discount.
     *
     * @return The discount type.
     */
    Discount getDiscount() const;

    /**
     * @brief Sets the customer associated with the payment.
     *
     * @param customer The customer object to set.
     */
    void setCustomer(const Customer& customer);

    /**
     * @brief Retrieves the customer associated with the payment.
     *
     * @return A Customer object representing the customer.
     */
    Customer getCustomer() const;

    /**
     * @brief Sets the cart associated with the payment.
     *
     * @param cart The cart object to set.
     */
    void setCart(const Cart& cart);

    /**
     * @brief Retrieves the cart associated with the payment.
     *
     * @return A Cart object representing the shopping cart.
     */
    Cart getCart() const;

    /**
     * @brief Calculates the grand total after applying discounts.
     *
     * @return The total price after discounts.
     */
    double grandTotal() const;

    /**
     * @brief Calculates the total cost of all items in the cart.
     *
     * @return The total price without discounts.
     */
    double total() const;

    /**
     * @brief Calculates the discount amount.
     *
     * @return The total discount applied.
     */
    double applyDiscount() const;

    /**
     * @brief Converts the discount type to a string representation.
     *
     * @return A string describing the discount percentage.
     */
    std::string discountPercentage() const;

    /**
     * @brief Applies a discount code to the payment.
     *
     * @param code The discount code as a QString.
     */
    void applyDiscountCode(const QString &code);

    /**
     * @brief Retrieves the details of the payment record.
     *
     * @return A QString containing the payment details.
     */
    QString getRecordDetails() const override;
};

#endif // PAYMENT_H
