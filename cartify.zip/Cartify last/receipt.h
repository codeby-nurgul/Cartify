#ifndef RECEIPT_H
#define RECEIPT_H

#include "purchaserecord.h"
#include "payment.h"

/**
 * @brief Represents a receipt for a completed purchase in the Cartify system.
 * 
 * The Receipt class extends the PurchaseRecord class and provides details
 * about the purchased items, discounts, and total cost. It also generates
 * a unique order number.
 */
class Receipt : public PurchaseRecord {
    Payment payment; ///< The payment details associated with this receipt.

public:
    /**
     * @brief Constructs a Receipt object with the given payment details.
     * 
     * @param payment The Payment object containing purchase details.
     */
    Receipt(const Payment& payment);

    /**
     * @brief Calculates the loyalty points earned from the purchase.
     * 
     * The points are calculated based on the total amount of the purchase.
     * 
     * @return The number of points earned.
     */
    int addPoint();

    /**
     * @brief Generates a unique order number for the receipt.
     * 
     * The order number is a randomly generated 6-digit number.
     * 
     * @return The generated order number as a QString.
     */
    QString orderNo() const;

    /**
     * @brief Converts the receipt details to a formatted string.
     * 
     * The string includes information about each purchased product,
     * the total cost, discounts applied, and the grand total.
     * 
     * @return A QString containing the receipt details.
     */
    QString toString() const;

    /**
     * @brief Retrieves the complete details of the receipt.
     * 
     * Combines the order number and receipt information into a single string.
     * 
     * @return A QString containing the full receipt details.
     */
    QString getRecordDetails() const override;
};

#endif // RECEIPT_H
