#include "productmanager.h"
#include <QPixmap>

/**
 * @brief Constructs a ProductManager object with the given list of products.
 * 
 * Initializes the ProductManager with the provided QVector of Product objects.
 * 
 * @param products A QVector containing the products to manage.
 */
ProductManager::ProductManager(const QVector<Product> &products)
    : products(products) {}

/**
 * @brief Sets up product buttons for the GUI.
 * 
 * This function assigns icons and styles to a QVector of QPushButton pointers
 * based on the products managed by the ProductManager. The setup starts from
 * the given index in the product list.
 * 
 * @param buttons A QVector of QPushButton pointers to configure.
 * @param startIndex The starting index in the product list. Defaults to 0.
 */
void ProductManager::setupProductButtons(const QVector<QPushButton *> &buttons, int startIndex) {
    for (int i = 0; i < buttons.size(); i++) {
        int productIndex = startIndex + i;

        if (productIndex >= products.size()) {
            buttons[i]->hide();
            continue;
        }

        const Product &product = products[productIndex];

        // Set the button icon
        QPixmap pixmap(product.getPicturePath());
        QIcon buttonIcon(pixmap);
        buttons[i]->setIcon(buttonIcon);
        buttons[i]->setIconSize(pixmap.size());

        // Style the button
        buttons[i]->setStyleSheet("border: 1px solid gray; padding: 5px; background-color: white;");
        buttons[i]->setText(QString("ID: %1\nPrice: %2 TL").arg(product.getId()).arg(product.getCost()));
        buttons[i]->show();
    }
}

/**
 * @brief Retrieves a product by its index.
 * 
 * This function returns a pointer to the Product object at the specified index
 * in the product list. If the index is out of bounds, it returns nullptr.
 * 
 * @param index The index of the product to retrieve.
 * @return A pointer to the Product object, or nullptr if the index is invalid.
 */
Product* ProductManager::getProductByIndex(int index) {
    if (index < 0 || index >= products.size()) {
        return nullptr;
    }

    return &products[index];
}
