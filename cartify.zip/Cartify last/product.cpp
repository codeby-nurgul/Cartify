#include "product.h"

/**
 * @brief Default constructor for the Product class.
 * 
 * Initializes the product with default values.
 */
Product::Product() : id(0), cost(0.0), likeCount(0) {}

/**
 * @brief Constructs a Product with the given details.
 * 
 * @param id The unique identifier for the product.
 * @param picturePath The file path to the product's image.
 * @param explanation The description of the product.
 * @param cost The cost of the product.
 * @param likeCount The initial like count for the product.
 */
Product::Product(int id, QString picturePath, QString explanation, double cost, int likeCount)
    : id(id), picturePath(picturePath), explanation(explanation), cost(cost), likeCount(likeCount) {}

/**
 * @brief Copy constructor for the Product class.
 * 
 * Copies the details of an existing product.
 * 
 * @param temp The product to copy.
 */
Product::Product(const Product& temp)
    : id(temp.id),
      picturePath(temp.picturePath),
      explanation(temp.explanation),
      cost(temp.cost),
      likeCount(temp.likeCount) {}

/**
 * @brief Retrieves the selected size of the product.
 * 
 * @return The selected size.
 */
Product::SIZE Product::getSelectedSize() const {
    return selectedSize;
}

/**
 * @brief Retrieves the selected size as a string.
 * 
 * Converts the selected size enum to a human-readable string.
 * 
 * @return A QString representing the size (e.g., "XS", "S").
 */
QString Product::getSizeString() const {
    switch(getSelectedSize()) {
    case SIZE::XSMALL: return "XS";
    case SIZE::SMALL:  return "S";
    case SIZE::MEDIUM: return "M";
    case SIZE::LARGE:  return "L";
    case SIZE::XLARGE: return "XL";
    }
}

/**
 * @brief Sets the selected size for the product.
 * 
 * @param size The size to set.
 */
void Product::setSelectedSize(SIZE size) {
    selectedSize = size;
}

/**
 * @brief Retrieves the product's ID.
 * 
 * @return The ID of the product.
 */
int Product::getId() const {
    return id;
}

/**
 * @brief Sets the product's ID.
 * 
 * @param value The ID to set.
 */
void Product::setId(int value) {
    id = value;
}

/**
 * @brief Retrieves the picture path of the product.
 * 
 * @return The file path to the product's image.
 */
QString Product::getPicturePath() const {
    return picturePath;
}

/**
 * @brief Sets the picture path for the product.
 * 
 * @param value The file path to set.
 */
void Product::setPicturePath(const QString& value) {
    picturePath = value;
}

/**
 * @brief Retrieves the product's description.
 * 
 * @return The description of the product.
 */
QString Product::getExplanation() const {
    return explanation;
}

/**
 * @brief Sets the product's description.
 * 
 * @param value The description to set.
 */
void Product::setExplanation(const QString& value) {
    explanation = value;
}

/**
 * @brief Retrieves the product's cost.
 * 
 * @return The cost of the product.
 */
double Product::getCost() const {
    return cost;
}

/**
 * @brief Sets the product's cost.
 * 
 * @param value The cost to set.
 */
void Product::setCost(double value) {
    cost = value;
}

/**
 * @brief Retrieves the number of likes for the product.
 * 
 * @return The number of likes.
 */
int Product::getLikeCount() const {
    return likeCount;
}

/**
 * @brief Sets the like count for the product.
 * 
 * @param value The like count to set.
 */
void Product::setLikeCount(int value) {
    likeCount = value;
}

/**
 * @brief Retrieves the comments associated with the product.
 * 
 * @return A QVector of comments.
 */
QVector<QString> Product::getComments() const {
    return comments;
}

/**
 * @brief Sets the comments for the product.
 * 
 * @param value A QVector of comments to set.
 */
void Product::setComments(const QVector<QString>& value) {
    comments = value;
}

/**
 * @brief Converts the product details to a QString.
 * 
 * @return A QString containing the product ID and cost.
 */
QString Product::toQString() const {
    return QString("ID: %1 Price: %2").arg(id).arg(cost);
}

/**
 * @brief Likes the product, incrementing the like count.
 */
void Product::likeProduct() {
    likeCount++;
}

/**
 * @brief Unlikes the product, decrementing the like count.
 * 
 * Ensures the like count does not go below zero.
 */
void Product::unlikeProduct() {
    if (likeCount > 0) likeCount--;
}

/**
 * @brief Adds a comment to the product.
 * 
 * @param comment The comment to add.
 */
void Product::addComment(const QString &comment) {
    comments.append(comment);
}
