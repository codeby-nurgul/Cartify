#include "Customer.h"
#include <QString>
#include "qdebug.h"

using namespace std;

/**
 * @brief Constructs a Customer object with the given details.
 */
Customer::Customer(QString name, QString surname, ProductType productType,
                   QString email, QString password)
    : name(name), surname(surname), productType(productType),
      email(email), password(password), point(0) {
}

/**
 * @brief Destructor for the Customer class.
 */
Customer::~Customer() {}

/**
 * @brief Checks if the cart is empty.
 * @param prod A product to check against (unused in logic).
 * @return True if the cart is empty, false otherwise.
 */
bool Customer::isCartEmpty(Product prod) {
    return cart.getProducts().empty();
}

/**
 * @brief Adds a product to the customer's favorites if it's not already present.
 * @param prod The product to add.
 * @return True if the product was successfully added, false otherwise.
 */
bool Customer::addFavorite(Product prod) {
    for (Product product : favorites) {
        if (prod.getId() == product.getId()) {
            return false;
        }
    }
    favorites.push_back(prod);
    return true;
}

/**
 * @brief Removes a product from the customer's favorites by ID.
 * @param id The ID of the product to remove.
 */
void Customer::removeFavorite(int id) {
    int index = 0;
    for (Product product : favorites) {
        if (product.getId() == id) {
            favorites.erase(favorites.begin() + index);
            break;
        }
        index++;
    }
}

/**
 * @brief Retrieves the customer's list of favorite products.
 * @return A QVector containing the customer's favorite products.
 */
QVector<Product> Customer::getFavorites() {
    return favorites;
}

/**
 * @brief Sets the customer's favorite products based on a string of IDs.
 * 
 * Parses a comma-separated string of product IDs and adds matching products
 * to the customer's favorites.
 * 
 * @param favorites A comma-separated string of product IDs.
 * @param products A QVector of available products.
 */
void Customer::setFavorites(QString favorites, QVector<Product> products) {
    QString id = "";
    for (int i = 0; i < favorites.length(); i++) {
        if (favorites.at(i) == ',') {
            for (Product product : products) {
                if (product.getId() == id.toInt()) {
                    qDebug() << product.getExplanation() << "  ";
                    this->addFavorite(product);
                    break;
                }
            }
            id = "";
        } else {
            id += favorites.at(i);
        }
    }
}

/**
 * @brief Adds a product to the customer's cart.
 * @param prod The product to add.
 */
void Customer::addCart(Product prod) {
    this->cart.addProduct(prod);
}

/**
 * @brief Removes a product from the customer's cart by ID.
 * @param id The ID of the product to remove.
 */
void Customer::removeCart(int id) {
    this->cart.removeProductById(id);
}

/**
 * @brief Retrieves the list of products in the customer's cart.
 * @return A vector of products currently in the cart.
 */
vector<Product> Customer::getCart() {
    return this->cart.getProducts();
}

/**
 * @brief Retrieves the customer's current points.
 * @return The number of points the customer has.
 */
int Customer::myPoints() const {
    return point;
}

/**
 * @brief Adds points to the customer's account.
 * @param amount The amount of points to add.
 */
void Customer::addPoint(int amount) {
    point += amount;
}

/**
 * @brief Retrieves the customer's cart object.
 * @return A Cart object representing the customer's shopping cart.
 */
Cart Customer::getCartObject() {
    return cart;
}

/**
 * @brief Marks a product as liked by the customer.
 * @param productId The ID of the product to like.
 * @return True if the product was successfully liked, false if it was already liked.
 */
bool Customer::likeProduct(int productId) {
    if (likedProductIds.find(productId) != likedProductIds.end()) {
        return false;
    }
    likedProductIds.insert(productId);
    return true;
}

/**
 * @brief Checks if the customer has liked a specific product.
 * @param productId The ID of the product to check.
 * @return True if the product is liked, false otherwise.
 */
bool Customer::hasLikedProduct(int productId) const {
    return likedProductIds.find(productId) != likedProductIds.end();
}

/**
 * @brief Adds a product to the customer's list of purchased products.
 * @param product The product to add.
 */
void Customer::addPurchasedProduct(const Product& product) {
    purchasedProducts.push_back(product);
}

/**
 * @brief Checks if the customer has purchased a specific product.
 * @param productId The ID of the product to check.
 * @return True if the product has been purchased, false otherwise.
 */
bool Customer::hasPurchasedProduct(int productId) const {
    for (const auto& p : purchasedProducts) {
        if (p.getId() == productId) {
            return true;
        }
    }
    return false;
}
