#include "NotificationSystem.h"

/**
 * @brief Constructs a NotificationSystem object.
 * 
 * Initializes the NotificationSystem with a parent widget for displaying
 * message boxes.
 * 
 * @param parent The parent widget. Defaults to nullptr.
 */
NotificationSystem::NotificationSystem(QWidget *parent)
    : parentWidget(parent) {}

/**
 * @brief Displays an informational message box.
 * 
 * This method uses QMessageBox to display an information dialog with the
 * specified title and message.
 * 
 * @param title The title of the message box.
 * @param message The informational message to display.
 */
void NotificationSystem::showInfo(const QString &title, const QString &message) {
    QMessageBox::information(parentWidget, title, message);
}

/**
 * @brief Displays a warning message box.
 * 
 * This method uses QMessageBox to display a warning dialog with the
 * specified title and message.
 * 
 * @param title The title of the message box.
 * @param message The warning message to display.
 */
void NotificationSystem::showWarning(const QString &title, const QString &message) {
    QMessageBox::warning(parentWidget, title, message);
}

/**
 * @brief Displays an error message box.
 * 
 * This method uses QMessageBox to display an error dialog with the
 * specified title and message.
 * 
 * @param title The title of the message box.
 * @param message The error message to display.
 */
void NotificationSystem::showError(const QString &title, const QString &message) {
    QMessageBox::critical(parentWidget, title, message);
}
