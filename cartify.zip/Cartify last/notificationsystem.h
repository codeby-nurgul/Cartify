#ifndef NOTIFICATIONSYSTEM_H
#define NOTIFICATIONSYSTEM_H

#include <QMessageBox>
#include <QString>
#include <QWidget>

/**
 * @brief The NotificationSystem class provides an interface for displaying
 * informational, warning, and error messages in a GUI application.
 */
class NotificationSystem {
public:
    /**
     * @brief Constructs a NotificationSystem object.
     * 
     * @param parent The parent widget for displaying message boxes. Defaults to nullptr.
     */
    explicit NotificationSystem(QWidget *parent = nullptr);

    /**
     * @brief Displays an informational message box.
     * 
     * @param title The title of the message box.
     * @param message The informational message to display.
     */
    void showInfo(const QString &title, const QString &message);

    /**
     * @brief Displays a warning message box.
     * 
     * @param title The title of the message box.
     * @param message The warning message to display.
     */
    void showWarning(const QString &title, const QString &message);

    /**
     * @brief Displays an error message box.
     * 
     * @param title The title of the message box.
     * @param message The error message to display.
     */
    void showError(const QString &title, const QString &message);

private:
    QWidget *parentWidget; ///< The parent widget for displaying message boxes.
};

#endif // NOTIFICATIONSYSTEM_H
