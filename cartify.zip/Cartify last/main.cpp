#include "mainwindow.h"

#include <QApplication>
#include <QString>
#include <QGraphicsDropShadowEffect>
#include <QPushButton>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QString css = R"(
        QMainWindow {
            background: qlineargradient(spread:pad, x1:1, y1:0, x2:0, y2:1,
                                        stop:0 rgba(135, 206, 250, 200),
                                        stop:1 rgba(144, 238, 144, 200));
            color: #333333;
        }

        QLabel {
            font-family: "Arial";
            font-size: 14pt;
            color: #555555;
        }

        QLineEdit {
            border: 2px solid #cccccc;
            border-radius: 5px;
            padding: 5px;
            font-family: "Times New Roman";
            font-size: 12pt;
            background-color: #ffffff;
        }

        QPushButton {
            background-color:#1a5276;
            color: white;
            border-radius: 15px;
            padding: 5px;
            font-size: 14pt;
            font-family: "Arial";
            border: none;
        }

        QPushButton:hover {
            background-color: #2e7d32;
        }

        QPushButton:pressed {
            background-color: #003d80;
        }

        QComboBox {
            background-color: white;
            border: 1px solid #aaaaaa;
            font-family: "Arial";
            font-size: 12pt;
            padding: 3px;
        }

        QComboBox QAbstractItemView {
            selection-background-color: #007bff;
            selection-color: white;
        }

        QListWidget{
            background-color:#eee;
        }
        QTextEdit {
            background-color: #eee;

            padding: 10px;
        }

    )";

    a.setStyleSheet(css);

    MainWindow w;



    w.show();
    return a.exec();
}
