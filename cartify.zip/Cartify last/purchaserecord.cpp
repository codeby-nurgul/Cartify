#include "purchaserecord.h"

/**
 * @brief Default constructor for the PurchaseRecord class.
 * 
 * Initializes the purchase date to the current date and time and the total amount to 0.
 */
PurchaseRecord::PurchaseRecord()
    : purchaseDate(QDateTime::currentDateTime()), totalAmount(0.0) {}

/**
 * @brief Constructs a PurchaseRecord with the specified date and amount.
 * 
 * @param date The date and time of the purchase.
 * @param amount The total amount of the purchase.
 */
PurchaseRecord::PurchaseRecord(QDateTime date, double amount)
    : purchaseDate(date), totalAmount(amount) {}

/**
 * @brief Retrieves the date and time of the purchase.
 * 
 * @return The purchase date as a QDateTime object.
 */
QDateTime PurchaseRecord::getPurchaseDate() const {
    return purchaseDate;
}

/**
 * @brief Sets the date and time of the purchase.
 * 
 * @param date The date and time to set.
 */
void PurchaseRecord::setPurchaseDate(const QDateTime& date) {
    purchaseDate = date;
}

/**
 * @brief Retrieves the total amount of the purchase.
 * 
 * @return The total amount of the purchase as a double.
 */
double PurchaseRecord::getTotalAmount() const {
    return totalAmount;
}

/**
 * @brief Sets the total amount of the purchase.
 * 
 * @param amount The amount to set.
 */
void PurchaseRecord::setTotalAmount(double amount) {
    totalAmount = amount;
}
