#ifndef PURCHASERECORD_H
#define PURCHASERECORD_H

#include <QString>
#include <QDateTime>

/**
 * @brief Represents a generic purchase record in the Cartify system.
 * 
 * The PurchaseRecord class provides a base for storing purchase details,
 * including the date and total amount. It serves as an abstract base class
 * for more specific types of purchase records.
 */
class PurchaseRecord {
protected:
    QDateTime purchaseDate; ///< The date and time of the purchase.
    double totalAmount;     ///< The total amount of the purchase.

public:
    /**
     * @brief Default constructor for the PurchaseRecord class.
     * 
     * Initializes the purchase date to the current date and time and the total amount to 0.
     */
    PurchaseRecord();

    /**
     * @brief Constructs a PurchaseRecord with the specified date and amount.
     * 
     * @param date The date and time of the purchase.
     * @param amount The total amount of the purchase.
     */
    PurchaseRecord(QDateTime date, double amount);

    /**
     * @brief Retrieves the details of the purchase record.
     * 
     * This is a pure virtual function to be implemented by derived classes.
     * 
     * @return A QString containing the details of the purchase record.
     */
    virtual QString getRecordDetails() const = 0;

    /**
     * @brief Retrieves the date and time of the purchase.
     * 
     * @return The purchase date as a QDateTime object.
     */
    QDateTime getPurchaseDate() const;

    /**
     * @brief Sets the date and time of the purchase.
     * 
     * @param date The date and time to set.
     */
    void setPurchaseDate(const QDateTime& date);

    /**
     * @brief Retrieves the total amount of the purchase.
     * 
     * @return The total amount of the purchase as a double.
     */
    double getTotalAmount() const;

    /**
     * @brief Sets the total amount of the purchase.
     * 
     * @param amount The amount to set.
     */
    void setTotalAmount(double amount);

    /**
     * @brief Virtual destructor for the PurchaseRecord class.
     * 
     * Ensures proper cleanup of derived classes.
     */
    virtual ~PurchaseRecord() = default;
};

#endif // PURCHASERECORD_H
