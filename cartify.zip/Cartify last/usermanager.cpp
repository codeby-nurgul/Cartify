/**
 * @file usermanager.cpp
 * @brief Implementation of the UserManager class.
 * 
 * This file provides the implementation of user authentication,
 * registration, and management functionalities.
 */

#include "usermanager.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>

/**
 * @brief Constructs a UserManager object with default values.
 */
UserManager::UserManager() 
    : currentUser("Default", "User", ProductType::Electronics, "default@domain.com", "password"){
}

/**
 * @brief Retrieves the currently logged-in user.
 * 
 * @return A reference to the Customer object representing the current user.
 */
Customer& UserManager::getCurrentUser() {
    return currentUser;
}

/**
 * @brief Authenticates a user based on their email and password.
 * 
 * Searches the user storage file for a matching email and password combination.
 * Updates the current user if authentication is successful.
 * 
 * @param email The email address provided for login.
 * @param password The password provided for login.
 * @param products A list of products to initialize the user's favorites.
 * @return True if authentication is successful, false otherwise.
 */
bool UserManager::login(const QString &email, const QString &password, const QVector<Product> &products) {
    QFile file("customerData.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "File not found!";
        return false;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList userData = line.split(",");
        if (userData.size() >= 5 && userData[3] == email && userData[4] == password) {
            currentUser = Customer(userData[0], userData[1],
                                   userData[2] == "Electronics" ? ProductType::Electronics : ProductType::Clothes,
                                   email, password);
            currentUser.setFavorites(userData.size() > 5 ? userData[5] : "", products);
            return true;
        }
    }

    file.close();
    return false;
}

/**
 * @brief Checks if a user is already registered based on their email.
 * 
 * Searches the user storage file for a matching email.
 * 
 * @param email The email address to check.
 * @return True if the email is already registered, false otherwise.
 */
bool UserManager::isRegistered(const QString &email) {
    QFile file("customerData.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "File not found!";
        return false;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList userData = line.split(",");
        if (userData.size() >= 4 && userData[3] == email) {
            return true;
        }
    }

    file.close();
    return false;
}

/**
 * @brief Registers a new user by saving their details.
 * 
 * Writes the new user's details to the user storage file and updates
 * the current user to the newly registered user.
 * 
 * @param name The first name of the user.
 * @param surname The last name of the user.
 * @param email The email address of the user.
 * @param password The password for the user.
 */
void UserManager::signUp(const QString &name, const QString &surname, const QString &email, const QString &password) {
    QFile file("customerData.txt");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        qDebug() << "File not found!";
        return;
    }

    QTextStream out(&file);
    out << name << "," << surname << ",Clothes," << email << "," << password << "\n";
    currentUser = Customer(name, surname, ProductType::Clothes, email, password);

    file.close();
}
