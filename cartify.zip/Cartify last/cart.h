#ifndef CART_H
#define CART_H

#include <vector>
#include "product.h"
using namespace std;

/**
 * @brief Represents a shopping cart that holds a collection of products.
 * 
 * The Cart class provides functionality to add, remove, and manage
 * products in a shopping cart. It also allows clearing the cart
 * and retrieving the list of products.
 */
class Cart {
private:
    /**
     * @brief List of products in the cart.
     */
    vector<Product> products;

public:
    /**
     * @brief Constructs an empty Cart object.
     */
    Cart();

    /**
     * @brief Adds a product to the cart.
     * 
     * @param product The product to be added to the cart.
     */
    void addProduct(const Product& product);

    /**
     * @brief Removes a product from the cart by its ID.
     * 
     * @param productId The ID of the product to remove.
     */
    void removeProductById(int productId);

    /**
     * @brief Retrieves the list of products in the cart.
     * 
     * @return A constant reference to the vector of products in the cart.
     */
    const vector<Product>& getProducts() const;

    /**
     * @brief Clears all products from the cart.
     */
    void clearCart();
};

#endif // CART_H
