#include "cart.h"

/**
 * @brief Default constructor for the Cart class.
 */
Cart::Cart() {}

/**
 * @brief Adds a product to the cart.
 * 
 * @param product The product to be added to the cart.
 */
void Cart::addProduct(const Product& product) {
    products.push_back(product);
}

/**
 * @brief Removes a product from the cart by its ID.
 * 
 * This function finds the product with the specified ID and removes it
 * from the list of products in the cart.
 * 
 * @param productId The ID of the product to remove.
 */
void Cart::removeProductById(int productId) {
    auto it = std::find_if(products.begin(), products.end(),
                           [productId](const Product& product) { return product.getId() == productId; });

    if (it != products.end()) {
        products.erase(it);
    }
}

/**
 * @brief Retrieves the list of products in the cart.
 * 
 * @return A constant reference to the vector of products in the cart.
 */
const std::vector<Product>& Cart::getProducts() const {
    return products;
}

/**
 * @brief Clears all products from the cart.
 */
void Cart::clearCart() {
    products.clear();
}
