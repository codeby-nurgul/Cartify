#ifndef PRODUCT_H
#define PRODUCT_H

#include <QString>
#include <QVector>

/**
 * @brief Represents a product in the Cartify system.
 * 
 * The Product class contains details about a product, including its ID,
 * picture path, description, cost, like count, comments, and size.
 */
class Product {

private:
    int id; ///< Unique identifier for the product.
    QString picturePath; ///< Path to the product's image.
    QString explanation; ///< Description of the product.
    double cost; ///< Cost of the product.
    int likeCount; ///< Number of likes the product has received.
    QVector<QString> comments; ///< Comments associated with the product.

public:
    /**
     * @brief Enum for available product sizes.
     */
    enum class SIZE { 
        XSMALL, ///< Extra Small size.
        SMALL,  ///< Small size.
        MEDIUM, ///< Medium size.
        LARGE,  ///< Large size.
        XLARGE  ///< Extra Large size.
    };

    SIZE selectedSize; ///< The selected size of the product.

    /**
     * @brief Default constructor for the Product class.
     */
    Product();

    /**
     * @brief Constructs a Product with the given details.
     * 
     * @param id The unique identifier for the product.
     * @param picturePath The file path to the product's image.
     * @param explanation The description of the product.
     * @param cost The cost of the product.
     * @param likeCount The initial like count for the product.
     */
    Product(int id, QString picturePath, QString explanation, double cost, int likeCount);

    /**
     * @brief Copy constructor for the Product class.
     * 
     * @param temp The product to copy.
     */
    Product(const Product& temp);

    /**
     * @brief Retrieves the product's ID.
     * 
     * @return The ID of the product.
     */
    int getId() const;

    /**
     * @brief Sets the product's ID.
     * 
     * @param value The ID to set.
     */
    void setId(int value);

    /**
     * @brief Retrieves the picture path of the product.
     * 
     * @return The file path to the product's image.
     */
    QString getPicturePath() const;

    /**
     * @brief Sets the picture path for the product.
     * 
     * @param value The file path to set.
     */
    void setPicturePath(const QString& value);

    /**
     * @brief Retrieves the product's description.
     * 
     * @return The description of the product.
     */
    QString getExplanation() const;

    /**
     * @brief Sets the product's description.
     * 
     * @param value The description to set.
     */
    void setExplanation(const QString& value);

    /**
     * @brief Retrieves the product's cost.
     * 
     * @return The cost of the product.
     */
    double getCost() const;

    /**
     * @brief Sets the product's cost.
     * 
     * @param value The cost to set.
     */
    void setCost(double value);

    /**
     * @brief Retrieves the number of likes for the product.
     * 
     * @return The number of likes.
     */
    int getLikeCount() const;

    /**
     * @brief Sets the like count for the product.
     * 
     * @param value The like count to set.
     */
    void setLikeCount(int value);

    /**
     * @brief Retrieves the comments associated with the product.
     * 
     * @return A QVector of comments.
     */
    QVector<QString> getComments() const;

    /**
     * @brief Sets the comments for the product.
     * 
     * @param value A QVector of comments to set.
     */
    void setComments(const QVector<QString>& value);

    /**
     * @brief Adds a comment to the product.
     * 
     * @param comment The comment to add.
     */
    void addComment(const QString &comment);

    /**
     * @brief Likes the product, incrementing the like count.
     */
    void likeProduct();

    /**
     * @brief Unlikes the product, decrementing the like count.
     * 
     * Ensures the like count does not go below zero.
     */
    void unlikeProduct();

    /**
     * @brief Retrieves the selected size of the product.
     * 
     * @return The selected size.
     */
    SIZE getSelectedSize() const;

    /**
     * @brief Sets the selected size for the product.
     * 
     * @param size The size to set.
     */
    void setSelectedSize(SIZE size);

    /**
     * @brief Retrieves the selected size as a string.
     * 
     * @return A QString representing the size (e.g., "XS", "S").
     */
    QString getSizeString() const;

    /**
     * @brief Converts the product details to a QString.
     * 
     * @return A QString containing the product ID and cost.
     */
    QString toQString() const;
};

#endif // PRODUCT_H
