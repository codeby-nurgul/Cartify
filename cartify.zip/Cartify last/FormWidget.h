#ifndef FORMWIDGET_H
#define FORMWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

/**
 * @brief A widget that provides a login and sign-up form interface.
 * 
 * This widget includes fields for email and password input, as well as 
 * buttons for logging in and signing up. It uses a grid layout for organization.
 */
class FormWidget : public QWidget
{
    Q_OBJECT

public:
    /**
     * @brief Constructs a FormWidget object.
     * 
     * @param parent The parent widget. Defaults to nullptr.
     */
    explicit FormWidget(QWidget *parent = nullptr);

private:
    QLabel *emailLabel;        ///< Label for the email field.
    QLineEdit *emailField;     ///< Input field for the user's email.

    QLabel *passwordLabel;     ///< Label for the password field.
    QLineEdit *passwordField;  ///< Input field for the user's password.

    QPushButton *loginButton;  ///< Button for logging in.
    QPushButton *signupButton; ///< Button for signing up.

    QGridLayout *formLayout;   ///< Layout manager for the form elements.
};

#endif // FORMWIDGET_H
