#include "FormWidget.h"

/**
 * @brief Constructs the FormWidget and initializes the UI elements.
 * 
 * The FormWidget provides a simple login and sign-up form. It includes
 * labels and fields for email and password input, as well as buttons
 * for login and sign-up actions.
 * 
 * @param parent The parent widget. Defaults to nullptr.
 */
FormWidget::FormWidget(QWidget *parent)
    : QWidget(parent)
{
    // Create UI elements
    emailLabel = new QLabel("E-mail", this);
    emailField = new QLineEdit(this);

    passwordLabel = new QLabel("Password", this);
    passwordField = new QLineEdit(this);
    passwordField->setEchoMode(QLineEdit::Password);

    loginButton = new QPushButton("LOG IN", this);
    signupButton = new QPushButton("Sign Up!", this);

    // Create the form layout
    formLayout = new QGridLayout(this);

    // Add elements to the layout
    formLayout->addWidget(emailLabel, 0, 0);
    formLayout->addWidget(emailField, 0, 1);
    formLayout->addWidget(passwordLabel, 1, 0);
    formLayout->addWidget(passwordField, 1, 1);
    formLayout->addWidget(loginButton, 2, 0, 1, 2); // Spans the entire row
    formLayout->addWidget(signupButton, 3, 0, 1, 2);

    // Set layout properties
    formLayout->setSpacing(10); // Spacing between elements
    formLayout->setContentsMargins(20, 20, 20, 20); // Margins around the form

    // Assign layout to the widget
    this->setLayout(formLayout);

    // Make UI responsive
    emailField->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    passwordField->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    loginButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    signupButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
}
