#include "payment.h"
#include <QDateTime>
#include <QString>

/**
 * @brief Constructs a Payment object with the given customer, cart, and discount.
 */
Payment::Payment(Customer customer, Cart cart, Discount discount)
    : PurchaseRecord(QDateTime::currentDateTime(), 0.0),
    customer(customer),
    cart(cart),
    discount(discount) {}

/**
 * @brief Sets the discount type.
 */
void Payment::setDiscount(Discount discount) {
    this->discount = discount;
}

/**
 * @brief Retrieves the currently applied discount.
 */
Discount Payment::getDiscount() const {
    return discount;
}

/**
 * @brief Sets the customer associated with the payment.
 */
void Payment::setCustomer(const Customer &customer) {
    this->customer = customer;
}

/**
 * @brief Retrieves the customer associated with the payment.
 */
Customer Payment::getCustomer() const {
    return customer;
}

/**
 * @brief Sets the cart associated with the payment.
 */
void Payment::setCart(const Cart &cart) {
    this->cart = cart;
}

/**
 * @brief Retrieves the cart associated with the payment.
 */
Cart Payment::getCart() const {
    return cart;
}

/**
 * @brief Calculates the grand total after applying discounts.
 */
double Payment::grandTotal() const {
    return total() - applyDiscount();
}

/**
 * @brief Calculates the total cost of all items in the cart.
 */
double Payment::total() const {
    double totalValue = 0.0;
    for (const Product &product : cart.getProducts()) {
        totalValue += product.getCost();
    }
    return totalValue;
}

/**
 * @brief Calculates the discount amount based on the applied discount type.
 */
double Payment::applyDiscount() const {
    double discountPercentage = 0.0;

    switch (discount) {
    case NoDiscount:
        discountPercentage = 0.0;
        break;
    case D10:
        discountPercentage = 10.0;
        break;
    case D20:
        discountPercentage = 20.0;
        break;
    case D50:
        discountPercentage = 50.0;
        break;
    default:
        discountPercentage = 0.0;
        break;
    }

    return (total() * discountPercentage) / 100.0;
}

/**
 * @brief Converts the discount type to a string representation.
 */
std::string Payment::discountPercentage() const {
    switch (discount) {
    case NoDiscount:
        return "No Discount";
    case D10:
        return "10%";
    case D20:
        return "20%";
    case D50:
        return "50%";
    default:
        return "Invalid Discount";
    }
}

/**
 * @brief Applies a discount code to the payment.
 */
void Payment::applyDiscountCode(const QString &code) {
    if (code == "D10") {
        discount = D10;
    } else if (code == "D20") {
        discount = D20;
    } else if (code == "D50") {
        discount = D50;
    } else {
        discount = NoDiscount;
    }
}

/**
 * @brief Retrieves the details of the payment record as a formatted QString.
 */
QString Payment::getRecordDetails() const {
    return QString("Payment Record\nDate: %1\nTotal: %2 TL\nDiscount: %3\nGrand Total: %4 TL")
        .arg(getPurchaseDate().toString())
        .arg(total())
        .arg(QString::fromStdString(discountPercentage()))
        .arg(grandTotal());
}
