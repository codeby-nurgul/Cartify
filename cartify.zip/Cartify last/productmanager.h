#ifndef PRODUCTMANAGER_H
#define PRODUCTMANAGER_H

#include <QVector>
#include <QPushButton>
#include "product.h"



/**
 * @brief Manages products and their interactions within the Cartify system.
 * 
 * The ProductManager class handles product data and provides functionalities
 * such as setting up product buttons for the GUI and retrieving product details.
 */
class ProductManager {
public:
    /**
     * @brief Constructs a ProductManager object with a list of products.
     * 
     * @param products A QVector containing the products to manage.
     */
    ProductManager(const QVector<Product> &products);

    /**
     * @brief Sets up product buttons for the GUI.
     * 
     * Assigns icons and styles to a list of QPushButtons based on the products
     * starting from the specified index.
     * 
     * @param buttons A QVector of QPushButton pointers to configure.
     * @param startIndex The starting index in the product list. Defaults to 0.
     */
    void setupProductButtons(const QVector<QPushButton *> &buttons, int startIndex = 0);

    /**
     * @brief Retrieves a product by its index.
     * 
     * Returns a pointer to the product at the specified index in the product list.
     * Returns nullptr if the index is out of bounds.
     * 
     * @param index The index of the product to retrieve.
     * @return A pointer to the Product object, or nullptr if the index is invalid.
     */
    Product* getProductByIndex(int index);

private:
    QVector<Product> products; ///< The list of products managed by this class.
};

#endif // PRODUCTMANAGER_H
