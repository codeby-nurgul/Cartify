// Customer.h
#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>
#include <vector>
#include <QString>
#include "Product.h"
#include "Cart.h"
#include <set>

using namespace std;

/**
 * @brief Enum for product types.
 */
enum class ProductType {
    Electronics, ///< Represents electronic products.
    Clothes      ///< Represents clothing products.
};

/**
 * @brief Represents a customer in the Cartify system.
 * 
 * The Customer class handles user-specific operations such as managing favorites,
 * adding products to the cart, and tracking points.
 */

class Customer {
    /**
     * @brief Set of product IDs liked by the customer.
     */
    std::set<int> likedProductIds;

public:


    Cart cart;
    /**
     * @brief Constructs a Customer object.
     * 
     * @param name The customer's first name.
     * @param surname The customer's surname.
     * @param productType The customer's preferred product type.
     * @param email The customer's email address.
     * @param password The customer's password.
     */
    Customer(QString name, QString surname, ProductType productType,
             QString email, QString password);

    /**
     * @brief Destructor for the Customer class.
     */
    ~Customer();


    /**
     * @brief Retrieves the customer's cart object.
     * @return A Cart object representing the customer's shopping cart.
     */
    Cart getCartObject();

    /**
     * @brief Adds points to the customer's account.
     * @param amount The amount of points to add.
     */
    void addPoint(int amount);

    /**
     * @brief Retrieves the customer's current points.
     * @return The number of points the customer has.
     */
    int myPoints() const;

    /**
     * @brief Checks if the cart is empty.
     * @param prod A product to check against.
     * @return True if the cart is empty, false otherwise.
     */
    bool isCartEmpty(Product prod);

    /**
     * @brief Adds a product to the customer's favorites.
     * @param prod The product to add.
     * @return True if the product was successfully added, false if it's already in favorites.
     */
    bool addFavorite(Product prod);

    /**
     * @brief Removes a product from the customer's favorites by ID.
     * @param id The ID of the product to remove.
     */
    void removeFavorite(int id);

    /**
     * @brief Retrieves the customer's list of favorite products.
     * @return A QVector containing the customer's favorite products.
     */
    QVector<Product> getFavorites();

    /**
     * @brief Sets the customer's favorite products based on a string of IDs.
     * @param favorites A comma-separated string of product IDs.
     * @param products A QVector of available products.
     */
    void setFavorites(QString favorites, QVector<Product> products);

    /**
     * @brief Adds a product to the customer's cart.
     * @param prod The product to add.
     */
    void addCart(Product prod);

    /**
     * @brief Removes a product from the customer's cart by ID.
     * @param id The ID of the product to remove.
     */
    void removeCart(int id);

    /**
     * @brief Retrieves the list of products in the customer's cart.
     * @return A vector of products currently in the cart.
     */
    vector<Product> getCart();

    /**
     * @brief Marks a product as liked by the customer.
     * @param productId The ID of the product to like.
     * @return True if the product was successfully liked, false if it was already liked.
     */
    bool likeProduct(int productId);

    /**
     * @brief Checks if the customer has liked a specific product.
     * @param productId The ID of the product to check.
     * @return True if the product is liked, false otherwise.
     */
    bool hasLikedProduct(int productId) const;

    /**
     * @brief Adds a product to the customer's list of purchased products.
     * @param product The product to add.
     */
    void addPurchasedProduct(const Product& product);

    /**
     * @brief Checks if the customer has purchased a specific product.
     * @param productId The ID of the product to check.
     * @return True if the product has been purchased, false otherwise.
     */
    bool hasPurchasedProduct(int productId) const;



    /**
    * @brief Retrieves the customer's first name.
    * 
    * @return A QString representing the customer's first name.
    */
    QString getName() const {
        return name;
    }


    /**
    * @brief Sets the customer's first name.
    * 
    * @param newName The new name to set for the customer.
    */
    void setName(const QString& newName) {
        name = newName;
    }


    /**
    * @brief Retrieves the customer's surname.
    * 
    * @return A QString representing the customer's surname.
    */
    QString getSurname() const {
        return surname;
    }

    
    /**
    * @brief Sets the customer's surname.
    * 
    * @param newSurname The new surname to set for the customer.
    */
    void setSurname(const QString& newSurname) {
        surname = newSurname;
    }


    /**
    * @brief Retrieves the customer's email address.
    * 
    * @return A QString representing the customer's email address.
    */
    QString getEmail() const {
        return email;
    }

    
    /**
    * @brief Sets the customer's password.
    * 
    * @param newPassword The new password to set for the customer.
    */
    void setPassword(const QString& newPassword) {
        password = newPassword;
    }
    //(no getter for security reasons)

    
    /**
    * @brief Retrieves the customer's preferred product type.
    * 
    * @return The ProductType representing the customer's preference.
    */
    ProductType getProductType() const {
        return productType;
    }

    
    /**
    * @brief Sets the customer's preferred product type.
    * 
    * @param newProductType The new product type to set for the customer.
    */
    void setProductType(ProductType newProductType) {
        productType = newProductType;
    }

    
    /**
    * @brief Retrieves the customer's accumulated points.
    * 
    * @return An integer representing the customer's points.
    */
    int getPoints() const {
        return point;
    }

    
    /**
    * @brief Sets the customer's accumulated points.
    * 
    * @param newPoints The new points value to set for the customer.
    */
    void setPoints(int newPoints) {
        point = newPoints;
    }

private:
    /**
     * @brief List of products purchased by the customer.
     */
    std::vector<Product> purchasedProducts;

    QString name;           ///< Customer's first name.
    QString surname;        ///< Customer's surname.
    QString email;          ///< Customer's email address.
    QString password;       ///< Customer's password.
    ProductType productType;///< Customer's preferred product type.
    int point;              ///< Customer's accumulated points.

    QVector<Product> favorites; ///< List of favorite products.
    QVector<Product> previousOrders; ///< List of previous orders.

};

#endif // CUSTOMER_H
