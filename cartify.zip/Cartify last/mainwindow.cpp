#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "customer.h"
#include "product.h"
#include <QPixmap>
#include <QIcon>
#include <QListWidget>
#include <QLabel>
#include <QDir>
#include <QCoreApplication>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMessageBox>
#include "payment.h"
#include "receipt.h"
#include <QTextEdit>
#include "NotificationSystem.h"
#include "UserManager.h"



#include "QTimer"
#include "QGraphicsEllipseItem"
#include "QRandomGenerator"

UserManager userManager;
QVector<Product> getProductsVector();

/**
 * @class MainWindow
 * @brief Represents the main window of the application and manages the user interface.
 * 
 * The MainWindow class is responsible for initializing and managing the graphical user interface (GUI),
 * as well as handling application logic such as notifications, animations, and user interactions.
 */

/**
 * @brief Constructs the MainWindow object and initializes the GUI.
 * 
 * This constructor sets up the main window, initializes various components like the notification system,
 * the graphics scene, and timers, and prepares the application state.
 * 
 * @param parent The parent widget. Defaults to nullptr.
 */

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , notificationSystem(new NotificationSystem(this))
    , currentProduct(nullptr)

    , scene(new QGraphicsScene(this))
    , timer(new QTimer(this))
    , currentAngle(0)
    , targetAngle(0)
    , wheelRewards({"1 Free Item", "10% Off", "20% Off", "50% Off"})
    , currentSpeed(10.0)
    , minSpeed(0.5)
    , deceleration(0.1)
    , blinkTimer(new QTimer(this))
    , blinkCount(0)
    , blinkState(false)
    , chosenSliceIndex(-1)

{
    
    ui->setupUi(this);
    ui->wheelGraphicsView->setScene(scene);
    ui->wheelGraphicsView->setRenderHint(QPainter::Antialiasing);
    ui->wheelGraphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->wheelGraphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->wheelGraphicsView->setFixedSize(220, 220);
    ui->wheelGraphicsView->setSceneRect(0, 0, 200, 200);
    ui->paymentMethodComboBox->setCurrentIndex(-1);
    colorMap = {
        {0, "#FF6F61"},
        {1, "#6B8E23"},
        {2, "#4682B4"},
        {3, "#FFD700"}
    };
    discountMap = {
        {"#FF6F61", 10},
        {"#6B8E23", 20},
        {"#4682B4", 30},
        {"#FFD700", 50}
    };


    wheel = new QGraphicsEllipseItem(0, 0, 200, 200);
    wheel->setPen(QPen(Qt::black, 2));
    wheel->setBrush(Qt::NoBrush);
    scene->addItem(wheel);

    for (int i = 0; i < 4; ++i) {
        QPainterPath path;
        path.moveTo(100, 100);
        double startAngle = i * 90.0;
        double endAngle = (i + 1) * 90.0;

        for (double angle = startAngle; angle <= endAngle; angle += 1.0) {
            double x = 100 + 100 * qCos(qDegreesToRadians(angle));
            double y = 100 + 100 * qSin(qDegreesToRadians(angle));
            path.lineTo(x, y);
        }
        path.closeSubpath();

        QGraphicsPathItem *sliceItem = new QGraphicsPathItem(path, wheel);
        sliceItem->setPen(QPen(Qt::black, 1));
        sliceItem->setBrush(QBrush(QColor(colorMap[i])));
        slices.append(sliceItem);
    }

    wheel->setTransformOriginPoint(100, 100);
    showDiscountColors();

    connect(timer, &QTimer::timeout, this, [=]() {
        currentAngle = fmod(currentAngle + currentSpeed, 360.0);
        wheel->setRotation(currentAngle);

        if (currentSpeed > minSpeed) {
            currentSpeed -= deceleration;
        } else {
            timer->stop();

            blinkCount       = 0;
            blinkState       = false;
            chosenSliceIndex = QRandomGenerator::global()->bounded(4);

            blinkTimer->start(300);
        }
    });


    connect(blinkTimer, &QTimer::timeout, this, [=]() {
        blinkCount++;

        QGraphicsPathItem *chosenSlice = slices[chosenSliceIndex];
        QString colorName = colorMap[chosenSliceIndex];
        QColor originalColor(colorName);

        if (!blinkState) {
            chosenSlice->setBrush(Qt::NoBrush);
            blinkState = true;
        } else {
            chosenSlice->setBrush(originalColor);
            blinkState = false;
        }

        if (blinkCount >= 6) {
            chosenSlice->setBrush(originalColor);

            blinkTimer->stop();

            int discount = discountMap[colorName];
            QMessageBox::information(this, "Congratulations!",
                                     QString("You won: %1% Off!").arg(discount));
            applyDiscount(discount);

            currentAngle = 0.0;
            wheel->setRotation(0.0);
            currentSpeed = 10.0;
        }
    });

    ui->password_input_signup->setEchoMode(QLineEdit::Password);
    ui->password_login->setEchoMode(QLineEdit::Password);

    ui->comboBoxClothes->setVisible(true);
    ui->sizeComboBox->setVisible(true);
    ui->sizeLabelRam->setVisible(false);
    ui->sizeLabelClothes->setVisible(true);


    products = getProductsVector();
    setupProductButtons();

    connect(ui->spinButton, &QPushButton::clicked, this, &MainWindow::spinWheel);

    connectProductButtons();
    connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::on_searchButton_clicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &MainWindow::on_applyDiscountButtonClicked);
    connect(ui->sizeComboBox, SIGNAL(currentTextChanged(const QString &)), this, SLOT(on_sizeComboBox_currentTextChanged(const QString &)));
    connect(ui->likeButton, &QPushButton::clicked, this, &MainWindow::on_likeButtonClicked);
    connect(ui->submitCommentButton, &QPushButton::clicked, this, &MainWindow::on_submitCommentButtonClicked);

    this->setFixedSize(this->width(), this->height());
    this->setWindowTitle("Cartify");
    ui->textBrowserReceipt->setStyleSheet("background-color: transparent;");

    QPixmap icon(":/res/resources/logo1.png");
    QIcon winicon(icon);
    this->setWindowIcon(winicon);
    int w = ui->logo_label1->width();
    int h = ui->logo_label1->height();
    ui->logo_label1->setPixmap(icon.scaled(w,h, Qt::KeepAspectRatio) );
    ui->logo_label2->setPixmap(icon.scaled(w,h, Qt::KeepAspectRatio) );

    QPixmap bagIcon(":/res/resources/shopping bag.png");
    ui->cartButton->setIcon(bagIcon);
    ui->cartButton->setFlat(true);
    ui->cartButton->setStyleSheet("QPushButton { background-color: transparent }");
    QPixmap profIcon(":/res/resources/profile.png");
    ui->profileButton->setIcon(profIcon);
    ui->profileButton->setFlat(true);
    ui->profileButton->setStyleSheet("QPushButton { background-color: transparent }");
    QPixmap logoutIcon(":/res/resources/logout.png");
    ui->logoutButton->setIcon(logoutIcon);
    ui->logoutButton->setFlat(true);
    ui->logoutButton->setStyleSheet("QPushButton { background-color: transparent }");

    QPixmap backIcon(":/res/resources/backLogo.png");
    ui->mainScreenButton->setIcon(backIcon);
    ui->mainScreenButton->setFlat(true);
    ui->mainScreenButton->setStyleSheet("QPushButton { background-color: transparent }");
    ui->pass_to_loginPage->setIcon(backIcon);
    ui->pass_to_loginPage->setFlat(true);
    ui->pass_to_loginPage->setStyleSheet("QPushButton { background-color: transparent }");

    QPixmap notLikedIcon(":/res/resources/kalpLogoNotLiked.png");
    ui->likeButton->setIcon(notLikedIcon);
    ui->likeButton->setFlat(true);
    ui->likeButton->setStyleSheet("QPushButton { background-color: transparent }");
}


/**
 * @brief Displays the discount colors and labels on the UI.
 * 
 * This method sets the background color, text color, and label text for each discount level.
 * The discounts are displayed as visually distinct labels with different colors representing
 * varying percentages of discounts.
 * 
 * - Label 1: 10% Off (Red)
 * - Label 2: 20% Off (Olive Green)
 * - Label 3: 30% Off (Steel Blue)
 * - Label 4: 50% Off (Gold)
 */
void MainWindow::showDiscountColors()
{
    ui->labelColor1->setStyleSheet("background-color: #FF6F61; color: white; font-weight: bold; padding: 5px; font-size:15px;");
    ui->labelColor1->setText("10% Off");

    ui->labelColor2->setStyleSheet("background-color: #6B8E23; color: white; font-weight: bold; padding: 5px; font-size:15px;");
    ui->labelColor2->setText("20% Off");

    ui->labelColor3->setStyleSheet("background-color: #4682B4; color: white; font-weight: bold; padding: 5px; font-size:15px;");
    ui->labelColor3->setText("30% Off");

    ui->labelColor4->setStyleSheet("background-color: #FFD700; color: black; font-weight: bold; padding: 5px; font-size:15px;");
    ui->labelColor4->setText("50% Off");
}

/**
 * @brief Handles the toggling of the gift wrap checkbox.
 * 
 * This method checks if the user has selected the gift wrap option. If the checkbox
 * is checked but the cart is empty, it displays a warning message and resets the checkbox
 * to its unchecked state.
 * 
 * @param checked Indicates whether the checkbox is checked (true) or unchecked (false).
 * 
 * @note The checkbox is blocked temporarily to prevent signal loops when resetting its state.
 */
void MainWindow::on_giftWrapCheckBox_toggled(bool checked)
{
    Customer &user = userManager.getCurrentUser();

    if (checked) {
        if (user.getCart().empty()) {
            QMessageBox::warning(this,
                                 "Gift Wrap Error",
                                 "Your cart is empty. You cannot select gift wrapping.");

            ui->giftWrapCheckBox->blockSignals(true);
            ui->giftWrapCheckBox->setChecked(false);
            ui->giftWrapCheckBox->blockSignals(false);
        }
    }
}

/**
 * @brief Initiates the spinning of the discount wheel.
 * 
 * This method checks if the user's cart is empty before allowing the wheel to spin.
 * If the cart is empty, it displays a warning message and prevents the spin action.
 * Otherwise, it resets the wheel's position, sets the initial speed, and starts the
 * spinning animation.
 * 
 * @note The spinning animation is controlled by a timer that updates the wheel's rotation.
 */
void MainWindow::spinWheel()
{
    Customer &user = userManager.getCurrentUser();
    if (user.getCart().empty()) {
        QMessageBox::warning(this, "Empty Cart",
                             "Your cart is empty. Discounts cannot be applied.");
        return;
    }

    currentAngle = 0.0;
    wheel->setRotation(0.0);

    currentSpeed = 10.0;

    timer->start(16);
}

/**
 * @brief Applies a discount to the current purchase.
 * 
 * This method sets the discount percentage for the current purchase, updates the 
 * `currentDiscount` variable, and displays an informational message to the user.
 * 
 * @param percentage The percentage value of the discount to be applied.
 * 
 * @note The `discountApplied` flag is set to true to indicate that a discount has been applied.
 */
void MainWindow::applyDiscount(int percentage) {
    currentDiscount = percentage;
    discountApplied = true;
    QMessageBox::information(this, "Info", QString("The discount is %1%").arg(currentDiscount));
}

/**
 * @brief Handles the search button click event.
 * 
 * This method retrieves the search query from the input field, normalizes it by trimming spaces,
 * and searches for matching products in the product list. If a match is found, the corresponding
 * product button is triggered. If no match is found, an informational message is displayed.
 * 
 * @note If the search query is empty, the user is prompted to enter a valid search term.
 */
void MainWindow::on_searchButton_clicked() {
    QString query = ui->lineEdit->text().trimmed().replace(" ", "");
    if (query.isEmpty()) {
        QMessageBox::information(this, "Search", "Please enter a search term.");
        return;
    }
    bool found = false;

    for (const Product &product : products) {
        QString normalizedExplanation = product.getExplanation().replace(" ", "");
        if (normalizedExplanation.contains(query, Qt::CaseInsensitive)) {
            on_productButtonClicked(const_cast<Product&>(product));
            found = true;
            break;
        }
    }
    if (!found) {
        QMessageBox::information(this, "Search", "No matching products found.");
    }
}

/**
 * @brief Handles the "Apply Discount" button click event.
 * 
 * This method validates the entered discount code and checks the user's points to determine
 * if the discount can be applied. If the code is valid and the user has sufficient points, 
 * the discount is applied to the payment and the user's points are updated. The grand total
 * is recalculated and displayed to the user.
 * 
 * @note The discount codes and their required points are as follows:
 * - D50: 50% discount, requires 300 points
 * - D20: 20% discount, requires 200 points
 * - D10: 10% discount, requires 100 points
 * 
 * @note If the discount code is invalid or the user does not have enough points, appropriate 
 * warning messages are displayed.
 */
void MainWindow::on_applyDiscountButtonClicked() {
    QString discountCode = ui->lineEdit_2->text();
    Customer &user = userManager.getCurrentUser();
    Cart userCart = user.getCartObject();
    Payment payment(user, userCart, Discount::NoDiscount);

    if (discountCode != "D10" && discountCode != "D20" && discountCode != "D50") {
        QMessageBox::warning(this, "Invalid Code",
                             "The discount code you entered is invalid. Please use D50, D20, or D10.");
        return;
    }

    if (discountCode == "D50") {
        if (user.myPoints() >= 300) {
            payment.setDiscount(Discount::D50);
            user.addPoint(-300);
        } else {
            QMessageBox::warning(this, "Insufficient Points",
                                 "You do not have enough points for 50% discount.");
            return;
        }
    } else if (discountCode == "D20") {
        if (user.myPoints() >= 200) {
            payment.setDiscount(Discount::D20);
            user.addPoint(-200);
        } else {
            QMessageBox::warning(this, "Insufficient Points",
                                 "You do not have enough points for 20% discount.");
            return;
        }
    } else if (discountCode == "D10") {
        if (user.myPoints() >= 100) {
            payment.setDiscount(Discount::D10);
            user.addPoint(-100);
        } else {
            QMessageBox::warning(this, "Insufficient Points",
                                 "You do not have enough points for 10% discount.");
            return;
        }
    }

    double grandTotal = payment.grandTotal();

    ui->label_13->setText(QString("Grand Total: %1 TL").arg(grandTotal));

    if (discountCode == "D50") {
        currentDiscount = 50;
    } else if (discountCode == "D20") {
        currentDiscount = 20;
    } else if (discountCode == "D10") {
        currentDiscount = 10;
    } else {
        currentDiscount = 0;
    }

    discountApplied = true;
    QMessageBox::information(this, "Discount Applied",
                             QString("Discount applied successfully: %1").arg(discountCode));
}

/**
 * @brief Configures a QPushButton to represent a product with an image.
 * 
 * This method sets the icon of the given button to the specified image, removes the button's 
 * background for a transparent look, and ensures the button is displayed in a flat style.
 * 
 * @param button A pointer to the QPushButton to be configured.
 * @param picturePath The file path to the image to be used as the button's icon.
 */
void MainWindow::setProductButton(QPushButton *button, const QString &picturePath) {
    QPixmap pixmap(picturePath);
    button->setIcon(pixmap);
    button->setFlat(true);
    button->setStyleSheet("QPushButton { background-color: transparent }");
}

/**
 * @brief Initializes and configures product buttons for the UI.
 * 
 * This method sets up product buttons for clothes and electronics categories. Each button is configured
 * with the corresponding product's image and mapped to the respective product object for interaction.
 * Buttons without corresponding products are hidden to maintain a clean UI.
 * 
 * @note The product images are loaded from the `products` vector, and the buttons are categorized as 
 * clothes and electronics.
 */
void MainWindow::setupProductButtons() {
    QVector<QPushButton *> clothesProductButtons = {
        ui->clothesProduct1, ui->clothesProduct2, ui->clothesProduct3, ui->clothesProduct4,
        ui->clothesProduct5, ui->clothesProduct6, ui->clothesProduct7, ui->clothesProduct8,
        ui->clothesProduct9, ui->clothesProduct10, ui->clothesProduct11, ui->clothesProduct12,
        ui->clothesProduct13, ui->clothesProduct14, ui->clothesProduct15, ui->clothesProduct16,
        ui->clothesProduct17, ui->clothesProduct18, ui->clothesProduct19, ui->clothesProduct20
    };
    QVector<QPushButton *> electronicsProductButtons = {
        ui->electronicsProduct1, ui->electronicsProduct2, ui->electronicsProduct3, ui->electronicsProduct4,
        ui->electronicsProduct5, ui->electronicsProduct6, ui->electronicsProduct7, ui->electronicsProduct8,
        ui->electronicsProduct9, ui->electronicsProduct10, ui->electronicsProduct11, ui->electronicsProduct12,
        ui->electronicsProduct13, ui->electronicsProduct14, ui->electronicsProduct15, ui->electronicsProduct16,
        ui->electronicsProduct17, ui->electronicsProduct18, ui->electronicsProduct19, ui->electronicsProduct20
    };

    for (int i = 0; i < clothesProductButtons.size(); ++i) {
        if (i < products.size()) {
            setProductButton(clothesProductButtons[i], products[i].getPicturePath());
            buttonProductMap.insert(clothesProductButtons[i], &products[i]);
            productButtons.append(clothesProductButtons[i]);
        } else {
            clothesProductButtons[i]->hide();
        }
    }

    int offset = clothesProductButtons.size();
    for (int i = 0; i < electronicsProductButtons.size(); ++i) {
        int productIndex = i + offset;
        if (productIndex < products.size()) {
            setProductButton(electronicsProductButtons[i], products[productIndex].getPicturePath());
            buttonProductMap.insert(electronicsProductButtons[i], &products[productIndex]);
            productButtons.append(electronicsProductButtons[i]);
        } else {
            electronicsProductButtons[i]->hide();
        }
    }
}

/**
 * @brief Connects product buttons to their click event handler.
 * 
 * This method iterates over all product buttons and connects their `clicked` signal to the 
 * `on_productButton_clicked` slot. This enables the application to respond to user interactions
 * with the product buttons.
 */
void MainWindow::connectProductButtons() {
    for (auto button : productButtons) {
        connect(button, &QPushButton::clicked, this, &MainWindow::on_productButton_clicked);
    }
}

/**
 * @brief Handles the click event for a product button.
 * 
 * This method identifies which product button was clicked by the user, retrieves the corresponding 
 * `Product` object from the `buttonProductMap`, and triggers the `on_productButtonClicked` method 
 * with the selected product.
 * 
 * @note The method uses the `sender()` function to determine the clicked button and ensures it exists 
 * in the `buttonProductMap` before proceeding.
 */
void MainWindow::on_productButton_clicked() {
    QPushButton *clickedButton = qobject_cast<QPushButton *>(sender());
    if (clickedButton && buttonProductMap.contains(clickedButton)) {
        Product *product = buttonProductMap.value(clickedButton);
        on_productButtonClicked(*product);
    }
}

/**
 * @brief Handles the selection of a product and updates the UI accordingly.
 * 
 * This method is called when a product button is clicked. It updates the current product details
 * in the UI, including the product explanation, image, cost, like count, and comments. The UI
 * page is switched to display detailed information about the selected product.
 * 
 * @param product Reference to the selected `Product` object.
 * 
 * @note The product image is scaled to fit the designated UI element while maintaining its aspect ratio.
 */
void MainWindow::on_productButtonClicked(Product& product)
{
    currentProduct = &product;

    ui->changingPage->setCurrentIndex(1);
    ui->product_explaination->setText(product.getExplanation());
    QPixmap productIcon(product.getPicturePath());
    int width = ui->product_image->width();
    int height = ui->product_image->height();
    ui->product_image->setPixmap(productIcon.scaled(width, height, Qt::KeepAspectRatio));
    ui->product_cost->setText(QString::number(product.getCost(), 'f', 2) + " TL");
    ui->likeCountLabel->setText(QString::number(product.getLikeCount()));
    displayCommentsForProduct(product);
}

/**
 * @brief Handles the click event for the "like" button.
 * 
 * This method allows the current user to "like" the currently selected product. If the product 
 * has already been liked by the user, an informational notification is displayed. Otherwise, 
 * the product's like count is updated, and the "like" button icon changes to indicate the action.
 * 
 * @note The method ensures a valid product is selected before proceeding with the action.
 * 
 * @see Customer::hasLikedProduct
 * @see Product::likeProduct
 */
void MainWindow::on_likeButtonClicked() {
    if (!currentProduct) {
        return;
    }
    int productId = currentProduct->getId();
    Customer &user = userManager.getCurrentUser();

    if (user.hasLikedProduct(productId)) {
        notificationSystem->showInfo("Already Liked", "You have already expressed your appreciation for this product.");
        return;
    }
    if (user.likeProduct(productId)) {
        currentProduct->likeProduct();
        ui->likeCountLabel->setText(QString::number(currentProduct->getLikeCount()));

        QPixmap likedIcon(":/res/resources/kalpLogoLiked.png");
        ui->likeButton->setIcon(likedIcon);
    }
}

/**
 * @brief Handles the click event for the "submit comment" button.
 * 
 * This method allows the current user to submit a comment for the selected product. The following 
 * conditions are validated before submitting the comment:
 * - The user must have purchased the product.
 * - The comment text must not be empty.
 * 
 * If the comment is valid, it is added to the product, and the comments section is updated. 
 * Informational or warning notifications are displayed based on the action or validation results.
 * 
 * @note The comment input field is cleared after a successful submission.
 */
void MainWindow::on_submitCommentButtonClicked() {
    if (!currentProduct) {
        return;
    }

    Customer &user = userManager.getCurrentUser();

    if (!user.hasPurchasedProduct(currentProduct->getId())) {
        notificationSystem->showWarning("Comment Not Allowed",
                                        "You can only comment on products you have purchased.");

        ui->commentTextEdit->clear();
        return;
    }

    QString comment = ui->commentTextEdit->toPlainText().trimmed();
    if (!comment.isEmpty()) {
        currentProduct->addComment(comment);
        displayCommentsForProduct(*currentProduct);
        ui->commentTextEdit->clear();
        notificationSystem->showInfo("Comment Added",
                                     "Your comment has been successfully added.");
    } else {
        notificationSystem->showWarning("Empty Comment",
                                        "Please write a comment before submitting.");
    }
}

/**
 * @brief Displays the comments for the specified product in the UI.
 * 
 * This method retrieves the list of comments associated with the given product
 * and populates the comment list widget with them. Existing comments in the widget
 * are cleared before adding the new comments.
 * 
 * @param product The `Product` object whose comments are to be displayed.
 */
void MainWindow::displayCommentsForProduct(const Product &product) {
    ui->commentListWidget->clear();
    for (const QString &comment : product.getComments()) {
        ui->commentListWidget->addItem(comment);
    }
}

/**
 * @brief Navigates to the sign-up page.
 * 
 * This method switches the current view in the stacked widget to the sign-up page
 * when the "Go to Sign Up" button is clicked.
 */
void MainWindow::on_gotoSignUp_clicked() {
    ui->stackedWidget->setCurrentIndex(1);
}

/**
 * @brief Handles the click event for the "Sign Up" button.
 * 
 * This method validates the input fields for the sign-up form. The following checks are performed:
 * - Name and surname must be at least 3 characters long.
 * - Email must contain ".com" to be considered valid.
 * - Password must be at least 3 characters long.
 * - The email must not already be registered.
 * 
 * If all validations pass, the user is registered through the `userManager` and navigated back
 * to the login page. If any validation fails, an appropriate warning is displayed to the user.
 * 
 * @note This method uses the `notificationSystem` to show warnings or errors.
 */
void MainWindow::on_signUpButton_clicked() {
    QString name = ui->name_input_signup->text();
    QString surname = ui->surname_input_signup->text();
    QString email = ui->email_input_signup->text();
    QString password = ui->password_input_signup->text();

    if (name.length() < 3) {
        notificationSystem->showWarning("Sign Up Failed", "Name must be at least 3 characters long.");
        return;
    }
    if (surname.length() < 3) {
        notificationSystem->showWarning("Sign Up Failed", "Surname must be at least 3 characters long.");
        return;
    }
    if (!email.contains(".com")) {
        notificationSystem->showWarning("Sign Up Failed", "Invalid email address.");
        return;
    }
    if (password.length() < 3) {
        notificationSystem->showWarning("Sign Up Failed", "Password must be at least 3 characters long.");
        return;
    }
    if (userManager.isRegistered(email)) {
        notificationSystem->showWarning("Sign Up Failed", "Email is already registered.");
        return;
    }
    userManager.signUp(name, surname, email, password);
    ui->stackedWidget->setCurrentIndex(0);
}

/**
 * @brief Handles the click event for the "Login" button.
 * 
 * This method attempts to log the user in using the provided email and password. 
 * If the login is successful:
 * - The current user's favorites are retrieved and populated in the favorites combo box.
 * - The UI is navigated to the main application page.
 * 
 * If the login fails, a warning is displayed, and the input fields for email and password are cleared.
 * 
 * @note This method uses the `userManager` to handle login logic and the `notificationSystem` to display warnings.
 */
void MainWindow::on_loginButton_clicked() {
    QString email = ui->email_login->text();
    QString password = ui->password_login->text();

    if (userManager.login(email, password, products)) {
        Customer &user = userManager.getCurrentUser();

        ui->favoritesComboBox->clear();
        for (const Product &product : user.getFavorites()) {
            ui->favoritesComboBox->addItem(QIcon(product.getPicturePath()), product.getExplanation());
        }

        ui->stackedWidget->setCurrentIndex(2);
    } else {
        notificationSystem->showWarning("Login Failed", "Invalid email or password.");
        ui->email_login->clear();
        ui->password_login->clear();
    }
}

/**
 * @brief Handles the click event for the "Electronics" button.
 * 
 * This method navigates the user to the electronics product page and adjusts the visibility
 * of UI components specific to the electronics category. 
 * 
 * - Clothes-related filters and labels are hidden.
 * - Electronics-related filters and labels are made visible.
 */
void MainWindow::on_electronicsButton_clicked() {
    ui->productsPage->setCurrentIndex(1);
    ui->comboBoxClothes->setVisible(false);
    ui->sizeComboBox->setVisible(true);
    ui->sizeLabelRam->setVisible(true);
    ui->sizeLabelClothes->setVisible(false);
}

/**
 * @brief Handles the click event for the "Clothes" button.
 * 
 * This method navigates the user to the clothes product page and adjusts the visibility
 * of UI components specific to the clothes category.
 * 
 * - Electronics-related filters and labels are hidden.
 * - Clothes-related filters and labels are made visible.
 */
void MainWindow::on_clothesButton_clicked() {
    ui->productsPage->setCurrentIndex(0);
    ui->comboBoxClothes->setVisible(true);
    ui->sizeComboBox->setVisible(false);
    ui->sizeLabelRam->setVisible(false);
    ui->sizeLabelClothes->setVisible(true);
}

/**
 * @brief Handles the click event for the "Main Screen" button.
 * 
 * This method resets the "like" button icon to its default (not liked) state and navigates
 * the user back to the main screen of the application.
 * 
 * @note This method assumes that the "like" button icon needs to be reset whenever the user
 * navigates back to the main screen.
 */
void MainWindow::on_mainScreenButton_clicked() {
    QPixmap notLikedIcon(":/res/resources/kalpLogoNotLiked.png");
    ui->likeButton->setIcon(notLikedIcon);
    ui->changingPage->setCurrentIndex(0);
}

/**
 * @brief Handles the click event for the "Logout" button.
 * 
 * This method logs the user out by performing the following actions:
 * - Navigates the UI back to the login page.
 * - Clears the current user's favorites combo box.
 * - Clears the email and password input fields on the login page.
 * 
 * @note The current user's session data is reset to ensure a clean state for the next login.
 */
void MainWindow::on_logoutButton_clicked() {
    ui->stackedWidget->setCurrentIndex(0);
    Customer &user = userManager.getCurrentUser();

    ui->favoritesComboBox->clear();
    ui->email_login->clear();
    ui->password_login->clear();
}

/**
 * @brief Handles the click event for the "Favorite Product" button.
 * 
 * This method adds the currently selected product to the user's list of favorites. If the product 
 * is successfully added as a favorite, it is also appended to the favorites combo box with its 
 * icon and description.
 * 
 * @note The current user is retrieved from the `userManager` to ensure the favorite action is user-specific.
 */
void MainWindow::on_product_favoriteButton_clicked() {
    Customer &user = userManager.getCurrentUser();
    if (user.addFavorite(*currentProduct)) {
        ui->favoritesComboBox->addItem(QIcon(currentProduct->getPicturePath()), currentProduct->getExplanation());
    }
}

/**
 * @brief Converts a product size enum value to its corresponding string representation.
 * 
 * This method maps the `Product::SIZE` enum values to their respective string equivalents,
 * such as "XSMALL", "SMALL", "MEDIUM", "LARGE", and "XLARGE".
 * 
 * @param size The `Product::SIZE` enum value to be converted.
 * @return A `QString` representing the size as a human-readable string. Returns an empty string
 * if the size does not match any known enum value.
 */
QString sizeToString(Product::SIZE size) {
    switch(size) {
    case Product::SIZE::XSMALL: return "XSMALL";
    case Product::SIZE::SMALL: return "SMALL";
    case Product::SIZE::MEDIUM: return "MEDIUM";
    case Product::SIZE::LARGE: return "LARGE";
    case Product::SIZE::XLARGE: return "XLARGE";
    default: return "";
    }
}

/**
 * @brief Handles the click event for the "Send to Cart" button.
 * 
 * This method adds the currently selected product to the user's cart and updates the purchases combo box 
 * with the product's icon, explanation, and selected size.
 * 
 * @note The product's size is converted to a string using the `sizeToString` function before appending 
 * it to the combo box display.
 */
void MainWindow::on_product_sendToCart_clicked() {
    Customer &user = userManager.getCurrentUser();
    user.addCart(*currentProduct);
    QIcon icon(currentProduct->getPicturePath());
    QString explanation = currentProduct->getExplanation();
    QString size = sizeToString(currentProduct->getSelectedSize());
    ui->myPurchasesComboBox->addItem(icon, explanation + " - " + size);
}

/**
 * @brief Handles the click event for the "Profile" button.
 * 
 * This method navigates the user to the profile page and updates the UI to display the 
 * current user's name, surname, and shopping credits.
 * 
 * @note The `welcomeLabel` and `pointsLabel` are updated with user-specific data retrieved 
 * from the `userManager`.
 */
void MainWindow::on_profileButton_clicked() {
    Customer &user = userManager.getCurrentUser();
    ui->changingPage->setCurrentIndex(2);
    ui->welcomeLabel->setText("Welcome, " + user.getName() + " " + user.getSurname());
    ui->pointsLabel->setText("Shopping Credits: " + QString::number(user.myPoints()));
}

/**
 * @brief Handles the click event for the "Discard" button.
 * 
 * This method removes the currently selected favorite product from the user's favorites list 
 * and updates the favorites combo box to reflect the change.
 * 
 * @note The product is identified by matching its explanation text with the current selection in the combo box.
 * Once found, it is removed from both the user's favorites and the combo box.
 */
void MainWindow::on_discardButton_clicked() {
    Customer &user = userManager.getCurrentUser();
    QString expl = ui->favoritesComboBox->currentText();
    for (const Product &prod : user.getFavorites()) {
        if (prod.getExplanation() == expl) {
            user.removeFavorite(prod.getId());
            break;
        }
    }
    ui->favoritesComboBox->removeItem(ui->favoritesComboBox->currentIndex());
}

/**
 * @brief Handles the click event for the "Send Favorite to Cart" button.
 * 
 * This method adds the currently selected favorite product to the user's cart and updates the 
 * purchases combo box with the product's icon, explanation, and selected size.
 * 
 * @note The product is identified by matching its explanation text with the current selection 
 * in the favorites combo box. Once found, it is added to the cart and the purchases combo box.
 */
void MainWindow::on_sendFavoriteToCartButton_clicked() {
    Customer &user = userManager.getCurrentUser();
    QString expl = ui->favoritesComboBox->currentText();
    for (const Product &prod : user.getFavorites()) {
        if (prod.getExplanation() == expl) {
            QIcon icon(prod.getPicturePath());
            QString explanation = prod.getExplanation();
            QString size = sizeToString(prod.getSelectedSize());
            ui->myPurchasesComboBox->addItem(icon, explanation + " - " + size);
            user.addCart(prod);
            break;
        }
    }
}

/**
 * @brief Handles the click event for the "Cart" button.
 * 
 * This method navigates the user to the cart page by changing the current index of the 
 * stacked widget.
 * 
 * @note This function assumes that the cart page is at index 3 of the stacked widget.
 */
void MainWindow::on_cartButton_clicked() {
    ui->changingPage->setCurrentIndex(3);
}


/**
 * @brief Handles the click event for the "Buy" button.
 * 
 * This method processes the user's purchase by performing the following actions:
 * - Validates the selected payment method and ensures the cart is not empty.
 * - Handles gift wrap and shipping fees if applicable.
 * - Applies discounts based on the user's points or entered discount code.
 * - Calculates the final grand total after applying discounts and additional fees.
 * - Generates a receipt in HTML format and displays it in the receipt browser.
 * - Clears the user's cart and updates the purchases combo box.
 * - Resets the discount state and navigates to the receipt page.
 * 
 * @note If any validation fails (e.g., missing payment method or invalid discount code), 
 * appropriate warning or informational messages are displayed.
 * 
 * @see Payment, Receipt
 */
void MainWindow::on_buyButton_clicked()
{

    QString selectedPaymentMethod = ui->paymentMethodComboBox->currentText();
    if (selectedPaymentMethod == "Select Payment Method" || selectedPaymentMethod.isEmpty()) {
        QMessageBox::warning(this, "Payment Method Missing",
                             "Please select a payment method to continue.");
        return;
    }

    Customer &user = userManager.getCurrentUser();
    if (user.getCart().empty()) {
        notificationSystem->showWarning("Nothing to Purchase",
                                        "You have no items in your cart. Add products to make a purchase.");
        return;
    }

    QString currentPaymentMethod = ui->paymentMethodComboBox->currentText();
    if (currentPaymentMethod.isEmpty()) {
        notificationSystem->showWarning("Payment Method Missing",
                                        "Please select a payment method to continue.");
        return;
    }

    bool isGiftWrapSelected = ui->giftWrapCheckBox->isChecked();
    const double giftWrapFee = 10.0;

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this,
                                  "Shipping Fee",
                                  "A shipping fee of 50 TL will be added to your order. "
                                  "Do you wish to continue?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply != QMessageBox::Yes) {
        notificationSystem->showInfo("Purchase Cancelled",
                                     "Your purchase was not completed.");
        return;
    }
    const double shippingFee = 50.0;

    Payment payment(user, user.getCartObject(), Discount::NoDiscount);

    double discountAmount = 0.0;
    if (discountApplied) {
        discountAmount = payment.total() * currentDiscount / 100.0;
        payment.setDiscount(Discount::NoDiscount);
    }
    else if (user.myPoints() >= 300) {
        payment.setDiscount(Discount::D50);
        user.addPoint(-300);
    } else if (user.myPoints() >= 200) {
        payment.setDiscount(Discount::D20);
        user.addPoint(-200);
    } else if (user.myPoints() >= 100) {
        payment.setDiscount(Discount::D10);
        user.addPoint(-100);
    }
    else if (!ui->lineEdit_2->text().isEmpty() &&
             ui->lineEdit_2->text() != "D50" &&
             ui->lineEdit_2->text() != "D20" &&
             ui->lineEdit_2->text() != "D10") {
        notificationSystem->showWarning("Invalid Discount Code",
                                        "The discount code you entered is invalid. "
                                        "Please use D50, D20, or D10.");
        return;
    }
    else {
        payment.setDiscount(Discount::NoDiscount);
    }

    double totalBeforeDiscount = payment.total();


    if (!discountApplied) {
        discountAmount = payment.applyDiscount();
    }

    double totalAfterDiscount = totalBeforeDiscount - discountAmount;
    double grandTotalWithShipping = totalAfterDiscount + shippingFee;
    double giftWrapExtra = 0.0;
    if (isGiftWrapSelected) {
        giftWrapExtra = giftWrapFee;
        QMessageBox::information(this,
                                 "Gift Wrap Selected",
                                 QString("Gift wrapping fee of %1 TL is added.")
                                     .arg(giftWrapFee));
    }
    double finalGrandTotal = grandTotalWithShipping + giftWrapExtra;

    Receipt receipt(payment);
    QString randomOrderNumber = receipt.orderNo();

    int gainedPoints = receipt.addPoint();
    user.addPoint(gainedPoints);

    for (const Product &prod : user.getCart()) {
        user.addPurchasedProduct(prod);
    }
    ui->changingPage->setCurrentIndex(4);
    QString receiptHtml;
    receiptHtml += R"(
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f8ff;
        color: #333;
        text-align: center;
    }
    h2 {
        background-color:rgb(170, 170, 255);
        color: red;
        margin-bottom: 20px;
        text-align: center;
        font-size: 24px;
        text-transform: uppercase;
        padding:15px;
        height:50px;
    }
    .product {
        border: 2px solid #8bc34a;
        border-radius: 10px;
        padding: 15px;
        margin: 15px auto;
        background-color: #ffecb3;
        max-width: 300px;
        text-align: center;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }
    .product img {
        max-width: 200px;
        max-height: 200px;
        border-radius: 8px;
        margin-bottom: 10px;
        border: 2px solid #333;
    }
    .product p {
        font-size: 16px;
        margin: 5px 0;
        color: #6d4c41;
    }
    .summary {
        margin-top: 20px;
        padding: 15px;
        background-color: #dcedc8;
        border-radius: 10px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        border: 2px solid #689f38;
    }
    .summary p {
        font-size: 16px;
        font-weight: bold;
        color: #1b5e20;
        margin: 10px 0;
    }
</style>
    )";

    receiptHtml += "<h2>Your Order Details</h2>";

    receiptHtml += "<div>";
    const auto &prodList = user.getCart();
    for (const Product &product : prodList) {
        receiptHtml += "<div class='product'>";
        QPixmap productImage(product.getPicturePath());
        if (!productImage.isNull()) {
            QString imagePath = product.getPicturePath();
            receiptHtml += QString("<img src='%1' style='max-width:200px; max-height:200px; display:block; margin:0 auto;'><br>")
                               .arg(imagePath);
        }


        receiptHtml += QString("<p><b>ID:</b> %1</p>").arg(product.getId());
        receiptHtml += QString("<p><b>Name:</b> %1</p>").arg(product.getExplanation());
        receiptHtml += QString("<p><b>Cost:</b> %1 TL</p>")
                           .arg(QString::number(product.getCost(), 'f', 2));
        receiptHtml += "</div>";
    }
    receiptHtml += "</div>";

    receiptHtml += "<div class='summary'>";
    receiptHtml += QString("<p><b>Order No:</b> %1</p>").arg(randomOrderNumber);
    receiptHtml += QString("<p><b>Total (Before Discount):</b> %1 TL</p>")
                       .arg(totalBeforeDiscount, 0, 'f', 2);
    receiptHtml += QString("<p><b>Discount Amount:</b> %1 TL</p>")
                       .arg(discountAmount, 0, 'f', 2);
    receiptHtml += QString("<p><b>Total (After Discount):</b> %1 TL</p>")
                       .arg(totalAfterDiscount, 0, 'f', 2);
    receiptHtml += QString("<p><b>Shipping Fee:</b> %1 TL</p>")
                       .arg(shippingFee, 0, 'f', 2);

    if (isGiftWrapSelected) {
        receiptHtml += QString("<p><b>Gift Wrap Fee:</b> %1 TL</p>")
                           .arg(giftWrapExtra, 0, 'f', 2);
    }
    receiptHtml += QString("<p><b>Grand Total:</b> %1 TL</p>")
                       .arg(finalGrandTotal, 0, 'f', 2);
    receiptHtml += QString("<p><b>Payment Method:</b> %1</p>")
                       .arg(selectedPaymentMethod);
    receiptHtml += QString("<p><b>Gained Points:</b> %1</p>")
                       .arg(gainedPoints);
    receiptHtml += "</div>";

    ui->textBrowserReceipt->clear();
    ui->textBrowserReceipt->setHtml(receiptHtml);

    user.cart.clearCart();
    ui->myPurchasesComboBox->clear();

    currentDiscount = 0;
    discountApplied = false;
}

/**
 * @brief Handles the click event for the "Remove" button.
 * 
 * This method removes the currently selected product from the user's cart and updates the purchases 
 * combo box. If the cart is already empty, an informational message is displayed to the user.
 * 
 * @note The product to be removed is identified by its index in the combo box and removed both 
 * from the combo box and the user's cart.
 * 
 * @see Customer::cart
 */
void MainWindow::on_removeButton_clicked() {
    Customer &user = userManager.getCurrentUser();
    if(ui->myPurchasesComboBox->count() != 0) {
        int comboBoxIndex = ui->myPurchasesComboBox->currentIndex();
        int productId = user.cart.getProducts().at(comboBoxIndex).getId();

        ui->myPurchasesComboBox->removeItem(comboBoxIndex);
        user.cart.removeProductById(productId);
    } else {
        notificationSystem->showInfo("Cart is already empty", "No product found to remove from your cart");
    }
}

/**
 * @brief Handles the text change event for the size combo box.
 * 
 * This method maps the selected size string from the combo box to the corresponding 
 * `Product::SIZE` enum value and updates the selected size of the currently active product.
 * 
 * @param arg1 The selected size as a string.
 * 
 * @note This method assumes that the combo box contains valid size options matching the 
 * `Product::SIZE` enum values. If no product is currently selected, the size change is ignored.
 * 
 * @see Product::SIZE, Product::setSelectedSize
 */
void MainWindow::on_sizeComboBox_currentTextChanged(const QString &arg1) {
    Product::SIZE selectedSize;
    if (arg1 == "XSMALL") {
        selectedSize = Product::SIZE::XSMALL;
    } else if (arg1 == "SMALL") {
        selectedSize = Product::SIZE::SMALL;
    } else if (arg1 == "MEDIUM") {
        selectedSize = Product::SIZE::MEDIUM;
    } else if (arg1 == "LARGE") {
        selectedSize = Product::SIZE::LARGE;
    } else if (arg1 == "XLARGE") {
        selectedSize = Product::SIZE::XLARGE;
    }
    if (currentProduct) {
        currentProduct->setSelectedSize(selectedSize);
    }
}

/**
 * @brief Handles the click event to navigate to the login page.
 * 
 * This method changes the current page of the stacked widget to display the login page.
 * 
 * @note This function assumes that the login page is at index 0 of the stacked widget.
 */
void MainWindow::on_pass_to_loginPage_clicked() {
    ui->stackedWidget->setCurrentIndex(0);
}

/**
 * @brief Handles the close event for the main window.
 * 
 * This method is triggered when the main window is about to close. It ensures that the 
 * user is logged out properly by calling the `on_logoutButton_clicked` method before the 
 * application exits.
 * 
 * @param event Pointer to the `QCloseEvent` object that contains information about the close event.
 * 
 * @note This ensures that any necessary cleanup or state reset associated with user logout is performed 
 * before the application is terminated.
 * 
 * @see MainWindow::on_logoutButton_clicked
 */
void MainWindow::closeEvent(QCloseEvent *event) {
    on_logoutButton_clicked();
}

/**
 * @brief Destructor for the MainWindow class.
 * 
 * This method releases dynamically allocated resources, including the user interface object 
 * and the notification system instance, to prevent memory leaks.
 */
MainWindow::~MainWindow() {
    delete ui;
    delete notificationSystem;
}

/**
 * @brief Reads product data from a text file and returns a vector of products.
 * 
 * This method parses the product information stored in a text file and creates `Product` objects
 * for each entry. Each product's details, such as ID, image path, explanation, cost, and number 
 * of likes, are extracted and stored in a `QVector` of `Product` objects.
 * 
 * @return A `QVector` containing all the products read from the file.
 * 
 * @note The file path is hardcoded as `:/res/resources/product1.txt`, which is expected to 
 * be a resource file. If the file cannot be opened, an empty vector is returned, and a debug 
 * message is printed.
 * 
 * @see Product
 */
QVector<Product> getProductsVector(){
    QVector<Product> products;
    QFile file(":/res/resources/product1.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Unable to open product file";
        return products;
    }
    QTextStream in(&file);
    Product currentProduct;
    bool readingProduct = false;
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.contains("productstart:")) {
            readingProduct = true;
            currentProduct = Product();
        } else if (line.contains("productend:") && readingProduct) {
            products.push_back(currentProduct);
            readingProduct = false;
        } else if (readingProduct) {
            if (line.contains("productid:")) {
                currentProduct.setId(line.mid(line.indexOf(":") + 1).trimmed().toInt());
            }
            if (line.contains("productpath:")) {
                currentProduct.setPicturePath(line.mid(line.indexOf(":") + 1).trimmed());
            } else if (line.contains("productexp:")) {
                currentProduct.setExplanation(line.mid(line.indexOf(":") + 1).trimmed());
            } else if (line.contains("cost:")) {
                currentProduct.setCost(line.mid(line.indexOf(":") + 1).trimmed().toDouble());
            } else if (line.contains("Number of likes:")) {
                currentProduct.setLikeCount(line.mid(line.indexOf(":") + 1).trimmed().toInt());
            }
        }
    }
    file.close();
    return products;
}
