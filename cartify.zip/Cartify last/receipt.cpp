#include "receipt.h"
#include <QRandomGenerator>

/**
 * @brief Constructs a Receipt object with the given payment details.
 * 
 * Initializes the receipt with payment information and sets the purchase
 * date and total amount based on the payment details.
 * 
 * @param payment The Payment object containing purchase details.
 */
Receipt::Receipt(const Payment& payment)
    : PurchaseRecord(payment.getPurchaseDate(), payment.grandTotal()),
      payment(payment) {}

/**
 * @brief Calculates the loyalty points earned from the purchase.
 * 
 * Points are calculated as 10% of the total purchase amount.
 * 
 * @return The number of points earned.
 */
int Receipt::addPoint() {
    return static_cast<int>(getTotalAmount() * 0.1);
}

/**
 * @brief Generates a unique order number for the receipt.
 * 
 * The order number is a randomly generated 6-digit number.
 * 
 * @return The generated order number as a QString.
 */
QString Receipt::orderNo() const {
    return QString::number(QRandomGenerator::global()->bounded(100000, 999999));
}

/**
 * @brief Converts the receipt details to a formatted string.
 * 
 * The string includes information about each purchased product,
 * the total cost, discounts applied, and the grand total.
 * 
 * @return A QString containing the receipt details.
 */
QString Receipt::toString() const {
    QString result = "Receipt Details:\n";
    for (const Product& product : payment.getCart().getProducts()) {
        result += QString("ID: %1 - Price: %2 TL\n")
                      .arg(product.getId())
                      .arg(product.getCost());
    }
    result += QString("Total: %1 TL\n").arg(payment.total());
    result += QString("Discount: %1\n").arg(QString::fromStdString(payment.discountPercentage()));
    result += QString("Grand Total: %1 TL\n").arg(payment.grandTotal());
    return result;
}

/**
 * @brief Retrieves the complete details of the receipt.
 * 
 * Combines the order number and receipt information into a single string.
 * 
 * @return A QString containing the full receipt details.
 */
QString Receipt::getRecordDetails() const {
    return QString("Order No: %1\n%2")
        .arg(orderNo())
        .arg(toString());
}
